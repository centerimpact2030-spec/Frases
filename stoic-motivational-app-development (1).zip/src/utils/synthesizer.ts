// =============================================
// CONFRONTO DIÁRIO — Quote Synthesis Engine
// Simulates an AI model generating and evolving
// phrases based on user likes/dislikes
// =============================================

import { Category, Quote } from '../types';
import { validateQuote } from './validation';

export interface EvolutionProfile {
  categoryWeights: Record<Category, number>;
  tonePreferences: Record<string, number>;
  totalEvaluations: number;
}

export const INITIAL_PROFILE: EvolutionProfile = {
  categoryWeights: {
    'Disciplina Silenciosa': 5,
    'Execução Implacável': 5,
    'Mentalidade Blindada': 5,
    'Resiliência Estoica': 5,
    'Antifragilidade': 5,
    'Clareza Mental': 5,
    'Responsabilidade Pessoal': 5,
    'Construção de Hábitos': 5,
  },
  tonePreferences: {
    introspective: 5,
    severe: 5,
    actionOriented: 5,
    stoicWisdom: 5,
  },
  totalEvaluations: 0,
};

// Tone template options
const HEADLINES: Record<string, string[]> = {
  severe: [
    "A mediocridade não tolera o silêncio do trabalho bem feito.",
    "A dor do arrependimento esmaga muito mais que o peso da disciplina.",
    "Ninguém se importa com as tuas desculpas de cansaço acumulado.",
    "O conforto é uma sepultura rasa que você cava para si mesmo.",
    "Sua mente fraca justifica a covardia que seu corpo executa.",
    "A fraqueza ama plateias, enquanto a virtude opera no absoluto escuro.",
  ],
  introspective: [
    "O maior adversário habita sob a pele que você veste diariamente.",
    "Quem teme o julgamento alheio já entregou as próprias rédeas.",
    "A clareza só emerge após o colapso das tuas velhas ilusões.",
    "Olhe para o abismo da sua procrastinação e admita a sua culpa.",
    "A tempestade externa é apenas um reflexo do teu desespero interno.",
    "Nenhum homem é livre se não governa os próprios impulsos.",
  ],
  actionOriented: [
    "A execução implacável pulveriza qualquer teoria covarde.",
    "Pare de negociar com a preguiça; execute o que foi determinado.",
    "O plano perfeito sem ação é apenas um delírio patético.",
    "Construa a muralha da sua rotina tijolo por tijolo hoje.",
    "A velocidade da sua evolução é proporcional ao seu desconforto.",
    "Erga-se antes do sol e domine o caos antes que ele domine você.",
  ],
  stoicWisdom: [
    "O sofrimento é o cinzel que esculpe as mentes verdadeiramente antifrágeis.",
    "O obstáculo não bloqueia o caminho; ele se torna o próprio caminho.",
    "Aceite o fardo da sua própria existência sem reclamar da carga.",
    "Despreze o supérfluo e concentre-se apenas naquilo que você controla.",
    "A calmaria é uma ilusão perigosa criada por tempos fáceis demais.",
    "A virtude não se curva diante da tragédia, ela se fortalece nela.",
  ],
};

const TEXT_FRAGMENTS_SITUATION: Record<string, string[]> = {
  severe: [
    "Você acorda procurando motivos para adiar o trabalho duro mais uma vez.",
    "O cansaço bate à porta e você imediatamente começa a negociar suas metas.",
    "Diante da primeira dificuldade real, sua mente busca um culpado externo.",
  ],
  introspective: [
    "Você busca validação nos olhos de pessoas que sequer sabem para onde vão.",
    "Sua atenção é sequestrada por distrações vazias que drenam a sua energia vital.",
    "O silêncio do fim do dia revela o vazio das promessas que você fez e descumpriu.",
  ],
  actionOriented: [
    "Você gasta horas planejando rotinas perfeitas que nunca saem do papel.",
    "O prazo aperta e a ansiedade consome o resto de clareza que lhe restava.",
    "A preguiça sussurra argumentos lógicos para que você desista de treinar hoje.",
  ],
  stoicWisdom: [
    "Circunstâncias adversas atingem sua rotina de forma totalmente inesperada.",
    "O caos externo tenta arrastar sua mente para um estado de pânico absoluto.",
    "A perda e a incerteza batem à sua porta sem pedir licença ou aviso prévio.",
  ],
};

const TEXT_FRAGMENTS_CONFRONTATION: Record<string, string[]> = {
  severe: [
    "Essa fraqueza disfarçada de cansaço é o que destrói o seu futuro.",
    "A verdade crua é que você prefere o conforto temporário à grandeza duradoura.",
    "Pare de fingir que você está se esforçando enquanto procrastina em segredo.",
  ],
  introspective: [
    "Ninguém virá resgatá-lo dessa letargia mental que você mesmo alimentou.",
    "Sua mente é um campo de batalha onde a covardia ganha espaço a cada minuto.",
    "Você se tornou escravo do prazer imediato e esqueceu o preço da excelência.",
  ],
  actionOriented: [
    "Abandone o drama emocional e foque estritamente no próximo passo prático.",
    "A única resposta digna para a fraqueza é o trabalho mudo e obstinado.",
    "Engula o choro, organize as ferramentas e execute a tarefa sem pestanejar.",
  ],
  stoicWisdom: [
    "Não culpe o destino pelo que é de sua inteira responsabilidade consertar.",
    "O que acontece lá fora importa pouco; o que importa é a sua resposta interna.",
    "Aprenda a receber o golpe sem se curvar e sem perder a clareza da mente.",
  ],
};

const TEXT_FRAGMENTS_CONSEQUENCE: Record<string, string[]> = {
  severe: [
    "Se continuar cedendo, você será apenas mais um figurante arrependido e frustrado.",
    "A mediocridade cobra um pedágio caro que será pago com anos de amargura.",
    "O tempo não perdoa os fracos; ele os engole sem deixar qualquer rastro de honra.",
  ],
  introspective: [
    "Sua autoconfiança definha toda vez que você quebra um compromisso consigo mesmo.",
    "Essa fuga constante cria um abismo intransponível entre quem você é e quem deveria ser.",
    "A covardia repetida petrifica sua alma num estado permanente de submissão.",
  ],
  actionOriented: [
    "A consistência diária é o único muro que separa o fracasso do triunfo real.",
    "Cada repetição completada no desconforto é um voto a favor da sua nova identidade.",
    "A ação destrói a ansiedade, enquanto a hesitação alimenta o seu pior inimigo.",
  ],
  stoicWisdom: [
    "A verdadeira liberdade consiste em não depender de circunstâncias favoráveis.",
    "O fogo prova o ouro, e a adversidade lapida as mentes que recusam a fraqueza.",
    "Assuma o controle do seu julgamento e você terá uma fortaleza inabalável.",
  ],
};

const HASHTAGS: Record<Category, string[]> = {
  'Disciplina Silenciosa': ['#Disciplina', '#FocoNoTrabalho', '#Silencio'],
  'Execução Implacável': ['#Execucao', '#SemDesculpas', '#Acao'],
  'Mentalidade Blindada': ['#MenteForte', '#BlindagemEmocional', '#Mentalidade'],
  'Resiliência Estoica': ['#Estoicismo', '#Virtude', '#Resiliencia'],
  'Antifragilidade': ['#Antifragil', '#Crescimento', '#Evolucao'],
  'Clareza Mental': ['#Clareza', '#Foco', '#Sabedoria'],
  'Responsabilidade Pessoal': ['#Autoresponsabilidade', '#Honra', '#Dever'],
  'Construção de Hábitos': ['#Habitos', '#Consistencia', '#Rotina'],
};

// Generates a random quote using a simulated evolution engine
export function synthesizeQuote(
  profile: EvolutionProfile,
  requestedCategory?: Category | 'all'
): Quote {
  // 1. Pick Category based on weights
  let category: Category;
  if (requestedCategory && requestedCategory !== 'all') {
    category = requestedCategory;
  } else {
    const categories = Object.keys(profile.categoryWeights) as Category[];
    const totalWeight = categories.reduce((sum, c) => sum + profile.categoryWeights[c], 0);
    let r = Math.random() * totalWeight;
    category = categories[categories.length - 1]; // Fallback
    for (const c of categories) {
      r -= profile.categoryWeights[c];
      if (r <= 0) {
        category = c;
        break;
      }
    }
  }

  // 2. Pick Tone based on weights
  type ToneKey = keyof typeof HEADLINES;
  const tones = Object.keys(profile.tonePreferences) as ToneKey[];
  const totalToneWeight = tones.reduce((sum, t) => sum + profile.tonePreferences[t], 0);
  let tr = Math.random() * totalToneWeight;
  let tone: ToneKey = 'severe'; // Fallback
  for (const t of tones) {
    tr -= profile.tonePreferences[t];
    if (tr <= 0) {
      tone = t;
      break;
    }
  }

  // Pick random headline from tone pool
  const headlinePool = HEADLINES[tone];
  const headline = headlinePool[Math.floor(Math.random() * headlinePool.length)];

  // Pick complementary components
  const sitPool = TEXT_FRAGMENTS_SITUATION[tone];
  const confPool = TEXT_FRAGMENTS_CONFRONTATION[tone];
  const consPool = TEXT_FRAGMENTS_CONSEQUENCE[tone];

  const sit = sitPool[Math.floor(Math.random() * sitPool.length)];
  const conf = confPool[Math.floor(Math.random() * confPool.length)];
  const cons = consPool[Math.floor(Math.random() * consPool.length)];

  const complementary_text = `${sit} ${conf} ${cons}`;

  // Pick 2-3 hashtags
  const catHashPool = HASHTAGS[category];
  const hashtags = [...catHashPool].sort(() => 0.5 - Math.random()).slice(0, 3);

  // Fallback to ensure counts are exactly right
  const result: Quote = {
    id: `synth_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    headline,
    complementary_text,
    category,
    hashtags,
    is_favorited: false,
    created_at: new Date().toISOString(),
    view_count: 0,
  };

  // Run auto validation or try again with minor length adjustments
  if (validateQuote(result.headline, result.complementary_text, result.hashtags)) {
    return result;
  }

  // Emergency shortener/lengthener if limits missed slightly
  if (result.complementary_text.length > 320) {
    result.complementary_text = result.complementary_text.slice(0, 317) + '...';
  }

  return result;
}

// Adjusts the learning profile based on interaction
export function evolveProfile(
  profile: EvolutionProfile,
  category: Category,
  isPositive: boolean
): EvolutionProfile {
  const newProfile = { ...profile };
  const delta = isPositive ? 2 : -2;

  // Adjust Category Weight (clamp between 1 and 20)
  const currentCatWeight = newProfile.categoryWeights[category] || 5;
  newProfile.categoryWeights[category] = Math.max(1, Math.min(20, currentCatWeight + delta));

  newProfile.totalEvaluations += 1;

  return newProfile;
}
