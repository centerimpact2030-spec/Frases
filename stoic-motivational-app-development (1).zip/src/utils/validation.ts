// =============================================
// CONFRONTO DIÁRIO — Content Validation Engine
// Ensures all quotes comply with strict rules
// =============================================

const CLICHE_LIST: string[] = [
  'acredite em você',
  'nunca desista',
  'você consegue',
  'tudo é possível',
  'siga seus sonhos',
  'o céu é o limite',
  'o impossível não existe',
  'você é especial',
  'basta querer',
  'pense positivo',
  'vai dar tudo certo',
  'força guerreiro',
  'deus no comando',
  'levanta e luta',
  'seja feliz',
  'ame a si mesmo',
  'você merece o melhor',
  'confie no processo',
  'confie no universo',
  'tudo acontece por uma razão',
  'o segredo é acreditar',
  'não desista dos seus sonhos',
  'brilhe sua luz',
  'você é mais forte do que pensa',
  'a vida é bela',
  'sorria sempre',
  'o melhor está por vir',
  'acredite no impossível',
  'mire na lua',
  'seja a mudança',
];

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

export function validateHeadline(headline: string): { valid: boolean; error?: string } {
  const words = countWords(headline);
  if (words < 4) return { valid: false, error: `Headline muito curta: ${words} palavras (mín: 4)` };
  if (words > 16) return { valid: false, error: `Headline muito longa: ${words} palavras (máx: 16)` };
  if (containsCliche(headline)) return { valid: false, error: 'Headline contém clichê' };
  return { valid: true };
}

export function validateComplementaryText(text: string): { valid: boolean; error?: string } {
  const len = text.length;
  if (len < 180) return { valid: false, error: `Texto muito curto: ${len} chars (mín: 180)` };
  if (len > 320) return { valid: false, error: `Texto muito longo: ${len} chars (máx: 320)` };
  if (containsCliche(text)) return { valid: false, error: 'Texto contém clichê' };
  return { valid: true };
}

export function validateHashtags(hashtags: string[]): { valid: boolean; error?: string } {
  if (hashtags.length < 2) return { valid: false, error: 'Mínimo 2 hashtags' };
  if (hashtags.length > 3) return { valid: false, error: 'Máximo 3 hashtags' };
  return { valid: true };
}

export function containsCliche(text: string): boolean {
  const lower = text.toLowerCase();
  return CLICHE_LIST.some(cliche => lower.includes(cliche));
}

export function validateQuote(headline: string, text: string, hashtags: string[]): boolean {
  return (
    validateHeadline(headline).valid &&
    validateComplementaryText(text).valid &&
    validateHashtags(hashtags).valid
  );
}
