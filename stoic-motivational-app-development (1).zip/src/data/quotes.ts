// =============================================
// CONFRONTO DIÁRIO — Pre-loaded Quotes Database
// 96 quotes across 8 categories (12 per category)
// All validated against content rules
// =============================================

import { Quote, Category } from '../types';

interface RawQuote {
  headline: string;
  complementary_text: string;
  category: Category;
  hashtags: string[];
}

const RAW_QUOTES: RawQuote[] = [
  // ============ DISCIPLINA SILENCIOSA ============
  {
    headline: 'Ninguém vai aplaudir os dias em que você escolheu continuar',
    complementary_text: 'A maioria das batalhas que definem quem você se torna acontece em silêncio. Sem plateia, sem reconhecimento. Quando todos dormem, você está acordado construindo algo que poucos entenderão. A disciplina real não busca validação — ela executa porque sabe que cada dia ignorado cobra juros compostos no futuro.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Consistência'],
  },
  {
    headline: 'Disciplina não é motivação. É decisão repetida até virar identidade.',
    complementary_text: 'Você não precisa estar inspirado para treinar, estudar ou trabalhar. Precisa apenas lembrar o que decidiu ser. A motivação é combustível barato que acaba rápido. A disciplina é o motor silencioso que funciona mesmo quando o entusiasmo morre. Quem depende de vontade perde para quem depende de sistema.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Identidade', '#Sistema'],
  },
  {
    headline: 'O silêncio da sua rotina constrói o que suas palavras prometem',
    complementary_text: 'Falar sobre metas gera dopamina falsa. O cérebro confunde declaração com execução. Enquanto isso, quem está em silêncio absoluto está empilhando resultados que falam por si. Pare de anunciar o que vai fazer. Deixe que o resultado final seja o único comunicado que você emite ao mundo.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Silêncio', '#Execução'],
  },
  {
    headline: 'Rotina sem glamour é o preço que poucos aceitam pagar',
    complementary_text: 'O mundo glorifica resultados e ignora o processo. Ninguém filma as horas monótonas de estudo, os treinos repetitivos, as noites de trabalho sem recompensa visível. A disciplina silenciosa é aceitar que o progresso real é tedioso, invisível e absolutamente necessário para quem recusa a mediocridade.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Processo'],
  },
  {
    headline: 'O que você faz quando ninguém observa define tudo',
    complementary_text: 'Caráter não é o que você demonstra em público — é o que pratica no escuro. Suas escolhas privadas moldam o resultado público. Se na solidão você escolhe conforto, distração e preguiça, nenhum discurso público corrige a trajetória. A verdade sobre quem você é mora nos seus hábitos invisíveis.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Caráter'],
  },
  {
    headline: 'A consistência vence o talento toda vez que o talento descansa',
    complementary_text: 'Talento sem estrutura é potencial desperdiçado. Enquanto o talentoso espera pela inspiração, o disciplinado já completou mais um ciclo. O mundo está cheio de pessoas brilhantes que não produziram nada relevante. A diferença entre potencial e resultado chama-se repetição deliberada, dia após dia, sem exceção.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Consistência', '#Execução'],
  },
  {
    headline: 'Cada atalho que você pega cobra pedágio no futuro',
    complementary_text: 'A pressa por resultados rápidos cria fragilidades estruturais. Quem pula etapas constrói em areia. O mercado, o corpo e os relacionamentos eventualmente testam a integridade da sua fundação. Se foi construída com atalhos, desmorona sob pressão. Disciplina é aceitar o caminho longo porque ele é o único que sustenta.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Paciência'],
  },
  {
    headline: 'Você não precisa de mais informação. Precisa de mais execução.',
    complementary_text: 'Consumir conteúdo virou a procrastinação intelectualmente aceitável. Você assiste, lê, anota — e faz zero. O conhecimento sem aplicação é entretenimento disfarçado de produtividade. A pessoa disciplinada sabe que uma ideia executada vale mais que mil ideias estudadas. Feche o navegador. Abra o editor. Trabalhe.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Execução', '#AçãoReal'],
  },
  {
    headline: 'O conforto de hoje é o arrependimento de amanhã disfarçado',
    complementary_text: 'Toda vez que você escolhe o sofá ao invés do treino, a distração ao invés do foco, a preguiça ao invés do esforço, está assinando um contrato com o seu eu futuro. E a cláusula diz: dor acumulada com juros. O conforto imediato é o anestésico que paralisa enquanto o tempo passa sem retorno.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Responsabilidade'],
  },
  {
    headline: 'Disciplina é dizer não para o que é bom para proteger o que é essencial',
    complementary_text: 'O inimigo da excelência não é o mal — é o medíocre disfarçado de aceitável. Cada sim para uma distração boa é um não para uma prioridade real. Quem não aprende a recusar oportunidades medianas nunca terá espaço para as que realmente importam. Proteja seu foco como se sua vida dependesse disso.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Foco', '#Prioridade'],
  },
  {
    headline: 'A dor do processo desaparece. A dor da desistência permanece.',
    complementary_text: 'Existe uma dor que fortalece e outra que corrói. A primeira vem do esforço, do treino, do trabalho duro — e passa quando o resultado aparece. A segunda vem de saber que você parou quando deveria ter continuado. Escolha qual dor carregar. Uma é temporária. A outra vai morar na sua memória para sempre.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Perseverança'],
  },
  {
    headline: 'Quem precisa de testemunhas para agir não está comprometido com o resultado',
    complementary_text: 'Se você só executa quando tem plateia, sua motivação é aprovação, não evolução. A disciplina real funciona em modo silencioso — sem stories, sem atualizações, sem validação externa. O compromisso genuíno com um objetivo não precisa de holofotes. Precisa de coerência entre o que você diz e o que faz sozinho.',
    category: 'Disciplina Silenciosa',
    hashtags: ['#Disciplina', '#Compromisso'],
  },

  // ============ EXECUÇÃO IMPLACÁVEL ============
  {
    headline: 'Planos sem prazo são apenas fantasias organizadas',
    complementary_text: 'Você pode ter o melhor plano do mundo no papel. Sem data, sem métrica, sem compromisso de entrega, é ficção. A execução implacável exige deadline, accountability e tolerância zero com desculpas. Cada dia sem ação concreta é um voto a favor da estagnação. Planeje menos. Execute mais. Ajuste no caminho.',
    category: 'Execução Implacável',
    hashtags: ['#Execução', '#Ação'],
  },
  {
    headline: 'A diferença entre sonho e projeto é uma planilha e um deadline',
    complementary_text: 'Sonhar é gratuito e confortável. Executar custa suor, ego e noites de sono. Quando você transforma um desejo vago em metas mensuráveis com prazos reais, o romantismo morre e a engenharia começa. Projetos reais têm números, fases e critérios de sucesso. O resto é autoengano sofisticado que você chama de ambição.',
    category: 'Execução Implacável',
    hashtags: ['#Execução', '#Planejamento'],
  },
  {
    headline: 'Perfeição é a desculpa mais elegante para a inação',
    complementary_text: 'Esperar o momento perfeito, o plano perfeito, a condição perfeita é procrastinação em traje de gala. Quem executa sabe que versão um sempre é imperfeita — e mesmo assim é infinitamente superior ao rascunho mental que nunca saiu da sua cabeça. Solte o trabalho. Corrija depois. Movimento imperfeito supera paralisia refinada.',
    category: 'Execução Implacável',
    hashtags: ['#Execução', '#Imperfeição'],
  },
  {
    headline: 'O mundo paga por resultados, não por intenções brilhantes',
    complementary_text: 'Sua boa intenção não paga boletos, não constrói reputação e não muda a realidade. O mercado, os relacionamentos e a vida respondem exclusivamente ao que foi entregue, não ao que foi planejado. Pare de se orgulhar do que pretende fazer. O orgulho legítimo vem apenas do que já foi concretizado e pode ser medido.',
    category: 'Execução Implacável',
    hashtags: ['#Resultados', '#Entrega'],
  },
  {
    headline: 'Velocidade de execução é a vantagem competitiva mais subestimada',
    complementary_text: 'Enquanto outros analisam, você implementa. Enquanto debatem, você testa. A velocidade não significa pressa descuidada — significa ciclos curtos de decisão, ação e ajuste. Quem se move primeiro aprende primeiro. Quem aprende primeiro domina o terreno. A lentidão estratégica é mito que protege os que têm medo de agir.',
    category: 'Execução Implacável',
    hashtags: ['#Velocidade', '#Execução'],
  },
  {
    headline: 'Cada reunião desnecessária é um roubo consentido do seu tempo',
    complementary_text: 'Reunir para alinhar o que poderia ser um parágrafo. Discutir o que poderia ser uma decisão unilateral. A cultura do consenso infinito mata a execução. Proteja seu tempo como recurso não renovável que é. Cada hora em conversa circular é uma hora roubada da criação real. Decida. Comunique. Execute. Revise depois.',
    category: 'Execução Implacável',
    hashtags: ['#Produtividade', '#Foco'],
  },
  {
    headline: 'Feito imperfeito supera perfeito adiado em qualquer métrica real',
    complementary_text: 'A primeira versão do que você entrega nunca será a ideal. E está tudo certo. O produto que existe no mercado corrige falhas em tempo real. O que está na sua cabeça apodrece em silêncio. Pare de polir e comece a publicar. O feedback do mundo real ensina mais em um dia do que meses de planejamento teórico.',
    category: 'Execução Implacável',
    hashtags: ['#Ação', '#Progresso'],
  },
  {
    headline: 'Desculpas são relatórios detalhados de onde você escolheu parar',
    complementary_text: 'Cada justificativa que você constrói é um mapa da sua zona de conforto. Falta de tempo, de dinheiro, de apoio — são narrativas que explicam inação, não realidade. Quem quer encontra método. Quem não quer encontra argumento. Suas desculpas contam a história real das suas prioridades. E a verdade é incômoda.',
    category: 'Execução Implacável',
    hashtags: ['#Responsabilidade', '#Execução'],
  },
  {
    headline: 'A procrastinação é uma dívida que cobra juros em oportunidades perdidas',
    complementary_text: 'Cada tarefa adiada acumula peso psicológico e fecha janelas de oportunidade. O que hoje custa uma hora, amanhã custará um dia. O que hoje é possível, amanhã pode ser tarde. A procrastinação não é descanso — é autossabotagem em câmera lenta. Reconheça o padrão, interrompa o ciclo e execute agora, não depois.',
    category: 'Execução Implacável',
    hashtags: ['#Execução', '#Urgência'],
  },
  {
    headline: 'Pensar demais é o veneno silencioso da produtividade real',
    complementary_text: 'Análise excessiva paralisa. Cada cenário hipotético que você simula mentalmente consome energia que deveria ir para a ação. Os melhores operadores do mundo pensam o suficiente para decidir e depois mergulham na execução. A clareza total vem fazendo, não pensando. Mova-se com informação incompleta e ajuste no percurso.',
    category: 'Execução Implacável',
    hashtags: ['#Ação', '#Decisão'],
  },
  {
    headline: 'Estratégia sem suor é palestra. Suor sem estratégia é desperdício.',
    complementary_text: 'O equilíbrio entre pensar e fazer é o que separa amadores de profissionais. Trabalhar duro na direção errada produz cansaço sem resultado. Planejar sem executar produz slides sem impacto. A execução implacável combina direção clara com esforço brutal. Saiba para onde vai. Depois, corra sem olhar para trás até chegar.',
    category: 'Execução Implacável',
    hashtags: ['#Estratégia', '#Execução'],
  },
  {
    headline: 'O medo de errar já é o primeiro erro que você cometeu',
    complementary_text: 'Enquanto calcula o risco de falhar, outros falham, aprendem e avançam. O medo do erro não protege — aprisiona. Cada tentativa traz dados reais. Cada falha elimina um caminho ruim. Quem evita erros evita aprendizado. A execução implacável aceita o erro como taxa de matrícula do progresso, não como sentença definitiva.',
    category: 'Execução Implacável',
    hashtags: ['#Coragem', '#Aprendizado'],
  },

  // ============ MENTALIDADE BLINDADA ============
  {
    headline: 'Opinião alheia só tem poder se você abrir a porta',
    complementary_text: 'A maioria das pessoas que opinam sobre sua vida não construíram a própria. Dar peso a críticas de quem nunca executou é sabotar seu processo com ruído irrelevante. Blinde sua mentalidade. Filtre brutalmente quem tem autoridade real para influenciar suas decisões. O resto é barulho que só afeta quem permite.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Mentalidade', '#Blindagem'],
  },
  {
    headline: 'Se todo mundo concorda com você, repense sua estratégia',
    complementary_text: 'Consenso é confortável e perigoso. Quando ninguém questiona seu plano, é provável que você esteja jogando seguro demais. As melhores decisões frequentemente causam desconforto social porque desafiam o padrão. Mentalidade blindada não busca aprovação — busca resultado. E resultado real muitas vezes nasce onde a maioria não tem coragem de ir.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Mentalidade', '#Independência'],
  },
  {
    headline: 'Emoção descontrolada é a falha de segurança da mente forte',
    complementary_text: 'Você pode ter a melhor estratégia, a melhor preparação e a melhor oportunidade. Se perde o controle emocional no momento decisivo, tudo desmorona. A mente blindada não elimina emoções — gerencia-as com precisão cirúrgica. Raiva, medo e ansiedade são sinais, não comandos. Quem obedece impulsos é escravo do momento.',
    category: 'Mentalidade Blindada',
    hashtags: ['#ControleEmocional', '#Mentalidade'],
  },
  {
    headline: 'O caos externo só domina quem não tem ordem interna',
    complementary_text: 'Crises revelam estrutura. Quando tudo ao redor desmorona, quem tem disciplina mental mantém a clareza para decidir. Quem não tem, reage por impulso e amplifica o problema. Construir ordem interna — rotinas, princípios, protocolos mentais — é o que separa quem navega tempestades de quem é arrastado por elas.',
    category: 'Mentalidade Blindada',
    hashtags: ['#OrdemInterna', '#Resiliência'],
  },
  {
    headline: 'Quem se ofende fácil entregou o controle para o provocador',
    complementary_text: 'A ofensa só funciona quando encontra ego frágil. Uma mente blindada reconhece a provocação, analisa sua relevância e decide conscientemente se merece reação. Na maioria dos casos, não merece. Reagir a cada estímulo externo é viver no modo automático, controlado por qualquer pessoa que saiba apertar seus botões emocionais.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Mentalidade', '#Controle'],
  },
  {
    headline: 'Validação externa é a droga mais socialmente aceita do século',
    complementary_text: 'Likes, elogios, aprovação — cada dose gera dependência e fragilidade. Quando sua autoestima depende do que outros dizem ou pensam, você constrói identidade sobre terreno alheio. A mentalidade blindada constrói valor próprio a partir de evidências internas: competência demonstrada, compromissos cumpridos, evolução mensurável. O resto é ruído.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Autoconhecimento', '#Mentalidade'],
  },
  {
    headline: 'Reclamar é confessar que você escolheu ser vítima da situação',
    complementary_text: 'Cada reclamação reforça a narrativa de impotência. Quando você reclama do trânsito, do chefe, do mercado, está declarando publicamente que não tem controle. A mente blindada substitui reclamação por diagnóstico e diagnóstico por ação. Não gosta da situação? Mude-a ou aceite-a estrategicamente. Reclamar nunca foi e nunca será solução.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Mentalidade', '#Responsabilidade'],
  },
  {
    headline: 'A dor que você evita hoje se acumula e cobra entrada amanhã',
    complementary_text: 'Fugir do desconforto é adiar o inevitável com juros. Conversas difíceis, decisões duras, verdades incômodas — tudo que você empurra para depois cresce em complexidade. A mente forte confronta o desconforto quando ele é pequeno, antes que vire crise. Evitar dor não é inteligência. É covardia emocional que cobra caro no longo prazo.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Confronto', '#Coragem'],
  },
  {
    headline: 'Seu pior inimigo não está lá fora. Mora entre seus ouvidos.',
    complementary_text: 'A voz interna que diz que você não é capaz, que é tarde demais, que outros são melhores — essa é a ameaça real. Nenhum concorrente externo é tão perigoso quanto a autossabotagem constante da sua própria mente. Blindar a mentalidade começa por identificar e silenciar as narrativas internas que trabalham contra seus objetivos.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Mentalidade', '#Autossabotagem'],
  },
  {
    headline: 'Quem vive para provar valor aos outros nunca encontra o próprio',
    complementary_text: 'A corrida por impressionar é infinita e vazia. Cada conquista motivada por aprovação alheia gera alívio temporário, não satisfação real. A mente blindada opera por métricas internas: estou melhor que ontem? Cumpri o que prometi a mim mesmo? Estou alinhado com meus valores? Essas respostas bastam. O resto é performance social inútil.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Autenticidade', '#Mentalidade'],
  },
  {
    headline: 'Conforto prolongado é o veneno mais doce que existe',
    complementary_text: 'Ele não mata rápido — anestesia devagar. Você se acostuma com o tolerável e abandona a busca pelo excelente. Dias se tornam meses, meses viram anos, e quando percebe, construiu uma vida inteira dentro da zona segura. A mente blindada reconhece o conforto como sinal de alerta, não como recompensa. Desconforto é direção.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Mentalidade', '#Desconforto'],
  },
  {
    headline: 'A calma sob pressão não é dom. É treino acumulado.',
    complementary_text: 'Ninguém nasce emocionalmente estável em situações extremas. Cada momento de controle sob caos foi construído por exposição repetida ao desconforto. A mente blindada se forja em treinos diários: decisões sob estresse, conversas incômodas, silêncio quando o impulso grita. Calma é habilidade treinável para quem aceita o processo.',
    category: 'Mentalidade Blindada',
    hashtags: ['#Calma', '#Treino'],
  },

  // ============ RESILIÊNCIA ESTOICA ============
  {
    headline: 'O obstáculo não bloqueia o caminho. O obstáculo é o caminho.',
    complementary_text: 'Cada barreira que aparece na sua trajetória carrega uma lição que você precisa aprender para avançar. Resistir ao problema é resistir ao crescimento. Os estoicos sabiam que a adversidade é o material bruto da evolução. Quando você para de lutar contra o obstáculo e começa a usá-lo, a transformação começa de forma irreversível.',
    category: 'Resiliência Estoica',
    hashtags: ['#Estoicismo', '#Resiliência'],
  },
  {
    headline: 'Você não controla o que acontece. Controla apenas como responde.',
    complementary_text: 'Demissões, traições, perdas, fracassos — a vida entrega golpes sem aviso. Gastar energia tentando controlar o incontrolável é desperdício existencial. O estoico direciona toda energia para o único território que domina: sua reação. E nessa reação mora o poder de transformar qualquer circunstância em ferramenta de construção pessoal.',
    category: 'Resiliência Estoica',
    hashtags: ['#Estoicismo', '#Controle'],
  },
  {
    headline: 'Sofrer pelo que ainda não aconteceu é viver duas vezes a mesma dor',
    complementary_text: 'A ansiedade é sofrimento antecipado por cenários que talvez nunca se concretizem. Você gasta energia real com problemas imaginários. O estoico vive no presente com preparação para o futuro, sem o desperdício emocional da preocupação improdutiva. Se o problema é real, aja. Se é hipotético, solte. Sua mente tem energia finita.',
    category: 'Resiliência Estoica',
    hashtags: ['#Estoicismo', '#Presença'],
  },
  {
    headline: 'A adversidade revela quem você realmente é, não quem diz ser',
    complementary_text: 'Na calma, todos são sábios, pacientes e generosos. A pressão real expõe o verdadeiro caráter. Quando o plano falha, o dinheiro acaba ou a relação rompe — aí aparece a versão real. Resiliência estoica não é aguentar tudo calado. É manter clareza, dignidade e capacidade de ação quando o cenário inteiro desmorona ao seu redor.',
    category: 'Resiliência Estoica',
    hashtags: ['#Resiliência', '#Caráter'],
  },
  {
    headline: 'Aceitar o que não pode ser mudado é o primeiro ato de força real',
    complementary_text: 'Aceitação não é resignação — é inteligência estratégica. Lutar contra a realidade consome energia sem gerar resultado. O estoico reconhece o que está fora do seu controle, aceita sem amargura e redireciona todo esforço para o que pode ser transformado. Essa distinção entre aceitar e desistir é o que separa sabedoria de fraqueza.',
    category: 'Resiliência Estoica',
    hashtags: ['#Aceitação', '#Estoicismo'],
  },
  {
    headline: 'O tempo destrói tudo. Use isso como combustível, não como desculpa.',
    complementary_text: 'Cada segundo que passa é irrecuperável. O estoico não lamenta o tempo perdido — extrai urgência dele. A consciência da finitude não paralisa; mobiliza. Sabendo que tudo acaba, cada decisão ganha peso, cada hora ganha valor, cada ação ganha propósito. Viver com urgência serena é a arte de quem entendeu que o relógio não espera.',
    category: 'Resiliência Estoica',
    hashtags: ['#MementoMori', '#Urgência'],
  },
  {
    headline: 'Recomeçar do zero não é fracasso. É prova de que você ainda joga.',
    complementary_text: 'Perder tudo e começar novamente exige mais força do que nunca ter caído. O fracasso elimina quem se define pelo resultado. Quem se define pelo processo reconstrói quantas vezes for necessário. Cada recomeço carrega a sabedoria das tentativas anteriores. O estoico sabe que a derrota é temporária quando o espírito se recusa a parar.',
    category: 'Resiliência Estoica',
    hashtags: ['#Resiliência', '#Recomeço'],
  },
  {
    headline: 'A gratidão pelo difícil é o nível mais alto de maturidade mental',
    complementary_text: 'Agradecer pelo fácil é natural. Reconhecer valor no sofrimento é raro. Os momentos mais duros da sua vida foram os que mais construíram quem você é hoje. O estoico não deseja dor, mas quando ela chega, extrai significado. Transformar adversidade em aprendizado não é otimismo cego — é sabedoria prática de quem se recusa a desperdiçar experiência.',
    category: 'Resiliência Estoica',
    hashtags: ['#Estoicismo', '#Maturidade'],
  },
  {
    headline: 'O estoico não elimina o sofrimento. Ele escolhe qual sofrimento vale carregar.',
    complementary_text: 'Toda vida contém dor. A diferença está em qual dor você seleciona. A dor do crescimento, do treino, da disciplina — essa constrói. A dor da estagnação, do arrependimento, da omissão — essa destrói. Resiliência não é ausência de sofrimento. É a capacidade de escolher conscientemente quais batalhas merecem sua energia limitada.',
    category: 'Resiliência Estoica',
    hashtags: ['#Estoicismo', '#Escolha'],
  },
  {
    headline: 'O que te derrubou ontem pode te fortalecer hoje se você permitir',
    complementary_text: 'Cicatrizes não são fraquezas — são registros de sobrevivência. Cada queda que não te destruiu adicionou uma camada de resistência ao seu sistema. O erro é revisitar a dor como vítima em vez de analisá-la como estrategista. Extraia a lição, descarte o drama e use a experiência como armadura para o próximo desafio que virá.',
    category: 'Resiliência Estoica',
    hashtags: ['#Resiliência', '#Força'],
  },
  {
    headline: 'Paciência estoica não é esperar parado. É construir em silêncio enquanto o tempo trabalha.',
    complementary_text: 'Confundir paciência com passividade é um erro fatal. O estoico paciente está em movimento constante — plantando, construindo, refinando. Ele apenas não exige que os frutos apareçam no seu cronograma. Entende que sementes plantadas com consistência germinam no momento certo, não no momento desejado.',
    category: 'Resiliência Estoica',
    hashtags: ['#Paciência', '#Estoicismo'],
  },
  {
    headline: 'A ferida que você não processa se torna o padrão que você repete',
    complementary_text: 'Dor não resolvida vira comportamento automático. Relacionamentos que terminam sempre igual, erros profissionais recorrentes, reações emocionais desproporcionais — tudo aponta para feridas ignoradas. O estoico confronta a dor internamente, com honestidade brutal, para que ela não se torne um ciclo perpétuo que sabota cada nova tentativa.',
    category: 'Resiliência Estoica',
    hashtags: ['#Autoconhecimento', '#Cura'],
  },

  // ============ ANTIFRAGILIDADE ============
  {
    headline: 'O que não te destrói deve te reconstruir mais forte, não igual',
    complementary_text: 'Sobreviver não é suficiente. Se você passa por uma crise e sai exatamente como entrou, desperdiçou a adversidade. O antifrágil usa cada impacto como material de construção. Cada falha vira protocolo, cada derrota vira dados, cada dor vira filtro. O objetivo não é resistir — é evoluir a cada golpe que a realidade entrega.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Evolução'],
  },
  {
    headline: 'Sistemas frágeis evitam estresse. Sistemas antifrágeis se alimentam dele.',
    complementary_text: 'Seu corpo fortalece sob carga. Sua mente afia sob pressão. Seus negócios inovam sob escassez. Evitar todo estresse cria atrofia — física, mental e estratégica. O antifrágil busca doses calculadas de desconforto porque sabe que cada estressor controlado constrói capacidade para enfrentar os incontroláveis que inevitavelmente virão.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Estresse'],
  },
  {
    headline: 'Proteger-se de todo risco é o maior risco que existe',
    complementary_text: 'Quem nunca arrisca nunca perde — mas também nunca ganha, nunca aprende e nunca evolui. A segurança total é uma prisão dourada onde o potencial apodrece. O antifrágil aceita riscos calculados, sabendo que a exposição controlada ao fracasso é o único caminho para construir capacidade real de navegação em cenários imprevisíveis.',
    category: 'Antifragilidade',
    hashtags: ['#Risco', '#Antifragilidade'],
  },
  {
    headline: 'Cada crise que você sobrevive amplia sua capacidade para a próxima',
    complementary_text: 'O primeiro fracasso dói como fim de mundo. O segundo, como lição dura. O terceiro, como dado estratégico. O antifrágil acumula experiência de crise até que situações que paralisam os outros se tornam operações rotineiras. Você não fica imune à dor — fica competente em navegar nela sem perder capacidade de decisão e ação.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Competência'],
  },
  {
    headline: 'A zona de conforto é uma zona de deterioração disfarçada',
    complementary_text: 'Músculos que não são desafiados atrofiam. Mentes que não enfrentam problemas novos enferrujam. Negócios que não inovam morrem. O conforto cria a ilusão de estabilidade enquanto corrói silenciosamente sua capacidade. O antifrágil sabe que crescimento exige fricção. Sem resistência, não há adaptação. Sem adaptação, há apenas declínio lento e invisível.',
    category: 'Antifragilidade',
    hashtags: ['#Crescimento', '#Desconforto'],
  },
  {
    headline: 'Fracasse rápido, aprenda rápido, reconstrua mais forte',
    complementary_text: 'A velocidade do fracasso determina a velocidade do aprendizado. Quem evita falhas por meses desperdiça meses. Quem falha em dias aprende em dias. O antifrágil não romanitza o erro — ele o usa como ferramenta de calibração. Cada tentativa fracassada elimina variáveis e aproxima da versão que funciona. Errar devagar é o verdadeiro desperdício.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Aprendizado'],
  },
  {
    headline: 'Quem depende de condições ideais colapsa na primeira mudança real',
    complementary_text: 'Construir sucesso que só funciona em cenário perfeito é construir em cristal. O antifrágil projeta sua vida para funcionar sob pressão, escassez e caos. Treina com menos recursos, opera com margem de erro, diversifica pontos de apoio. Quando a mudança chega — e sempre chega — ele não só sobrevive. Ele capitaliza enquanto outros entram em pânico.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Adaptação'],
  },
  {
    headline: 'A dor voluntária de hoje é o seguro contra o colapso de amanhã',
    complementary_text: 'Treinar duro quando poderia descansar. Estudar quando poderia se distrair. Economizar quando poderia gastar. Cada dose voluntária de desconforto é um investimento em capacidade futura. O antifrágil não espera a crise para se preparar — ele se prepara diariamente para que, quando a crise vier, seja apenas mais um dia de operação normal.',
    category: 'Antifragilidade',
    hashtags: ['#Preparação', '#Antifragilidade'],
  },
  {
    headline: 'Previsibilidade é conforto. Imprevisibilidade é oportunidade.',
    complementary_text: 'Rotinas previsíveis criam competência local e fragilidade global. Quando a variável inesperada aparece, o previsível não tem repertório para responder. O antifrágil cultiva exposição ao imprevisível em doses controladas: novos ambientes, novos desafios, novas perspectivas. Cada surpresa processada aumenta seu vocabulário de respostas para o caos real.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Oportunidade'],
  },
  {
    headline: 'O frágil busca estabilidade. O antifrágil busca capacidade de adaptação.',
    complementary_text: 'Estabilidade é ilusão em um mundo que muda constantemente. Apostar na permanência é apostar contra a natureza da realidade. O antifrágil investe em flexibilidade: habilidades transferíveis, mentalidade adaptável, estruturas que se reconfiguram sob pressão. Não importa o que muda — importa sua velocidade de adaptação à nova configuração.',
    category: 'Antifragilidade',
    hashtags: ['#Adaptação', '#Flexibilidade'],
  },
  {
    headline: 'Redundância não é desperdício. É inteligência contra o imprevisível.',
    complementary_text: 'Ter plano B, reserva financeira, habilidades extras — parece excessivo até que o plano A falha. O antifrágil constrói camadas de proteção que parecem desnecessárias em tempos bons. Quando a crise chega, essas camadas são a diferença entre colapso e continuidade. O que o frágil chama de exagero, o antifrágil chama de sobrevivência projetada.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Estratégia'],
  },
  {
    headline: 'Ordem excessiva gera fragilidade. Caos controlado gera evolução.',
    complementary_text: 'Ambientes perfeitamente organizados criam sistemas que quebram ao primeiro imprevisto. Introduzir variabilidade calculada — mudanças de rotina, desafios novos, exposição a falhas menores — fortalece o todo. O antifrágil entende que perfeição operacional é inimiga da adaptabilidade e prefere sistemas robustos a sistemas bonitos.',
    category: 'Antifragilidade',
    hashtags: ['#Antifragilidade', '#Caos'],
  },

  // ============ CLAREZA MENTAL ============
  {
    headline: 'Clareza não é saber tudo. É saber o que importa agora.',
    complementary_text: 'Informação em excesso gera paralisia, não inteligência. Clareza mental é a capacidade de filtrar o essencial do irrelevante e agir com foco cirúrgico. Quando você sabe exatamente qual é a próxima ação mais importante, o ruído desaparece. Reduza variáveis, simplifique decisões e proteja sua atenção como recurso escasso que é.',
    category: 'Clareza Mental',
    hashtags: ['#ClarezaMental', '#Foco'],
  },
  {
    headline: 'Uma mente cheia de opiniões alheias não tem espaço para pensamento próprio',
    complementary_text: 'Redes sociais, notícias, podcasts, vídeos — você consome pensamento de outros o dia inteiro. Quando sobra espaço para o seu? Clareza mental exige períodos de silêncio informacional. Desconecte, reflita, questione. O pensamento original nasce no vazio, não no excesso. Quem não cultiva silêncio mental vive como eco das vozes alheias.',
    category: 'Clareza Mental',
    hashtags: ['#ClarezaMental', '#Silêncio'],
  },
  {
    headline: 'Decisão rápida com informação suficiente supera decisão perfeita que nunca chega',
    complementary_text: 'Esperar por certeza absoluta é esperar para sempre. O mundo real opera com dados incompletos e janelas curtas. Clareza mental é saber quando você tem informação suficiente para agir, mesmo sem garantia. O custo da indecisão quase sempre supera o custo de uma decisão imperfeita que pode ser corrigida no caminho.',
    category: 'Clareza Mental',
    hashtags: ['#Decisão', '#ClarezaMental'],
  },
  {
    headline: 'O ruído que você consome define a qualidade do pensamento que produz',
    complementary_text: 'Se a entrada é lixo informacional, a saída será confusão mental. Cada minuto em conteúdo raso, polêmicas fabricadas ou entretenimento vazio ocupa espaço cognitivo que poderia processar ideias relevantes. Proteja sua dieta informacional com o mesmo rigor da dieta alimentar. Mente clara exige entrada limpa e processamento sem interferência.',
    category: 'Clareza Mental',
    hashtags: ['#ClarezaMental', '#DietaInformacional'],
  },
  {
    headline: 'Simplificar é mais difícil que complicar. E infinitamente mais poderoso.',
    complementary_text: 'Complexidade é refúgio de quem não entende o suficiente para simplificar. Quando você realmente domina um assunto, consegue reduzi-lo à essência. Clareza mental se manifesta na capacidade de tornar o complexo acessível — em decisões, comunicação e estratégia. Se não consegue explicar simplesmente, ainda não entendeu profundamente.',
    category: 'Clareza Mental',
    hashtags: ['#Simplicidade', '#ClarezaMental'],
  },
  {
    headline: 'Multitarefa é a ilusão de produtividade que destrói a profundidade',
    complementary_text: 'Seu cérebro não faz duas coisas ao mesmo tempo — alterna rapidamente entre elas, perdendo qualidade em ambas. Cada troca de contexto custa energia cognitiva e tempo de reaquecimento. Clareza mental exige monotarefa: uma coisa por vez, com presença total. O resultado de uma hora focada supera quatro horas fragmentadas em qualquer cenário.',
    category: 'Clareza Mental',
    hashtags: ['#Foco', '#Profundidade'],
  },
  {
    headline: 'Pensar com clareza quando está calmo é fácil. O teste é pensar sob pressão.',
    complementary_text: 'Qualquer pessoa raciocina bem em condições ideais. O diferencial aparece quando o prazo aperta, o dinheiro acaba ou o plano falha. Treinar clareza mental sob estresse é habilidade de sobrevivência: respirar antes de reagir, separar fatos de interpretações, manter foco na ação possível. Isso se constrói com prática, não com teoria.',
    category: 'Clareza Mental',
    hashtags: ['#ClarezaMental', '#Pressão'],
  },
  {
    headline: 'A resposta que você procura geralmente está no silêncio que você evita',
    complementary_text: 'Ficar sozinho com os próprios pensamentos é desconfortável porque força honestidade. O barulho constante funciona como anestesia que impede o autoconhecimento. Clareza mental nasce quando você para de fugir do silêncio e começa a usá-lo como ferramenta de diagnóstico. O que emerge no quieto é o que realmente importa e precisa de atenção.',
    category: 'Clareza Mental',
    hashtags: ['#Silêncio', '#Autoconhecimento'],
  },
  {
    headline: 'Quem tenta resolver tudo ao mesmo tempo não resolve nada direito',
    complementary_text: 'A mente sobrecarregada produz decisões fracas. Quando você empilha problemas sem hierarquizar, a energia se dispersa e nenhum avança significativamente. Clareza mental é cruel na priorização: escolha o mais urgente, resolva completamente, passe ao próximo. Sequência, não simultaneidade. Isso exige coragem para ignorar o que grita mais alto mas importa menos.',
    category: 'Clareza Mental',
    hashtags: ['#Priorização', '#ClarezaMental'],
  },
  {
    headline: 'Escrever seus pensamentos é a forma mais eficaz de organizar o caos interno',
    complementary_text: 'O que está na cabeça parece complexo. No papel, revela-se frequentemente simples, confuso ou contraditório. Escrever força estrutura: início, desenvolvimento, conclusão. Clareza mental se constrói pelo hábito de externalizar pensamentos, analisá-los com distanciamento e reorganizá-los com lógica. Mente clara escreve. Mente confusa apenas rumina em loop.',
    category: 'Clareza Mental',
    hashtags: ['#ClarezaMental', '#Escrita'],
  },
  {
    headline: 'Dizer não é a ferramenta de foco mais poderosa que você subestima',
    complementary_text: 'Cada sim para algo irrelevante é um não implícito para algo essencial. Clareza mental se manifesta na capacidade de recusar com firmeza e sem culpa. Projetos, convites, oportunidades medianas — tudo que não serve ao objetivo principal precisa ser cortado. Foco não é sobre o que você faz. É sobre tudo que você escolhe não fazer.',
    category: 'Clareza Mental',
    hashtags: ['#Foco', '#Prioridade'],
  },
  {
    headline: 'A confusão mental é sintoma de valores mal definidos',
    complementary_text: 'Quando você não sabe o que é inegociável na sua vida, qualquer oferta parece boa e qualquer direção parece válida. Valores claros funcionam como bússola automática: decisões que antes exigiam horas de deliberação se resolvem em segundos. Defina o que importa. Descarte o resto. A clareza operacional nasce da clareza existencial.',
    category: 'Clareza Mental',
    hashtags: ['#Valores', '#ClarezaMental'],
  },

  // ============ RESPONSABILIDADE PESSOAL ============
  {
    headline: 'Se a sua vida não está como deveria, o espelho tem a resposta',
    complementary_text: 'É confortável culpar circunstâncias, pessoas, o governo, o mercado. Mas a maioria dos resultados que você tem são consequência direta das escolhas que fez ou se recusou a fazer. Responsabilidade pessoal começa quando você para de apontar dedos e começa a auditar suas próprias decisões com honestidade impiedosa e sem justificativas.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Responsabilidade', '#Honestidade'],
  },
  {
    headline: 'Culpar os outros é terceirizar o controle da sua própria história',
    complementary_text: 'Cada vez que você atribui seu fracasso a fatores externos, está declarando que não tem poder sobre sua vida. A responsabilidade pessoal é dolorosa porque elimina todas as desculpas confortáveis. Mas também é libertadora porque coloca o volante de volta nas suas mãos. Se o problema é seu, a solução também pode ser. E isso é poder real.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Responsabilidade', '#Poder'],
  },
  {
    headline: 'Ninguém está vindo salvar você. E isso é a melhor notícia que existe.',
    complementary_text: 'Esperar resgate externo é a forma mais refinada de passividade. Quando você aceita que ninguém tem obrigação de resolver seus problemas, assume o protagonismo da própria narrativa. Essa responsabilidade pesa, mas liberta. Porque se ninguém controla seu destino exceto você, então ninguém pode limitar seu potencial exceto você mesmo.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Protagonismo', '#Responsabilidade'],
  },
  {
    headline: 'Suas desculpas são um mapa preciso das suas fraquezas não enfrentadas',
    complementary_text: 'Ouça suas próprias justificativas com atenção clínica. Cada desculpa recorrente aponta para uma deficiência que você se recusa a resolver. Falta de tempo? Gestão deficiente. Falta de dinheiro? Planejamento falho. Falta de sorte? Falta de preparação. A responsabilidade pessoal exige que você traduza cada desculpa em diagnóstico e cada diagnóstico em plano de ação.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Responsabilidade', '#Autocrítica'],
  },
  {
    headline: 'O privilégio da liberdade vem com o peso da responsabilidade total',
    complementary_text: 'Você quer liberdade para escolher sua carreira, seus relacionamentos, seu estilo de vida. Mas liberdade sem responsabilidade é caos. Cada escolha livre gera consequências que são exclusivamente suas. Não existe liberdade sem peso. Aceitar isso é maturidade. Recusar é infantilidade emocional disfarçada de rebeldia contra o sistema.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Liberdade', '#Responsabilidade'],
  },
  {
    headline: 'A vítima tem razão. O protagonista tem resultado.',
    complementary_text: 'Você pode estar absolutamente certo sobre a injustiça que sofreu. O sistema é desigual, as pessoas são desleais, as circunstâncias são adversas. E nada disso muda o fato de que continuar na posição de vítima não produz transformação. Ter razão não paga boleto. Ação estratégica, mesmo em cenário injusto, produz resultados que reclamação nunca produzirá.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Protagonismo', '#Ação'],
  },
  {
    headline: 'Prometer e não cumprir é a forma mais rápida de destruir credibilidade',
    complementary_text: 'Cada promessa quebrada, por menor que seja, erode a confiança que os outros depositam em você — e pior, a confiança que você deposita em si mesmo. Responsabilidade pessoal começa com integridade verbal: só prometa o que pode entregar. E entregue sempre mais do que prometeu. Sua palavra é seu contrato mais importante.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Integridade', '#Palavra'],
  },
  {
    headline: 'Assumir erros custa ego. Esconder erros custa futuro.',
    complementary_text: 'Quando você admite um erro rapidamente, controla os danos e mantém a confiança. Quando esconde, o erro cresce em silêncio até explodir em proporções incontroláveis. Responsabilidade pessoal é engolir o orgulho e dizer falhei antes que alguém descubra. O ego ferido se recupera. A reputação destruída por mentira quase nunca se reconstrói.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Responsabilidade', '#Humildade'],
  },
  {
    headline: 'Você não é produto do seu passado. É resultado das decisões que toma agora.',
    complementary_text: 'O passado explica, mas não determina. Usar a história pessoal como justificativa para inação é escolher a prisão de um roteiro que você tem poder de reescrever. Cada momento presente oferece uma bifurcação: repetir o padrão ou quebrá-lo. Responsabilidade pessoal é exercer esse poder de escolha com consciência, mesmo quando o padrão confortável insiste em voltar.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Escolha', '#Presente'],
  },
  {
    headline: 'Se você tolera mediocridade, está comunicando ao mundo que merece mediocridade',
    complementary_text: 'Os padrões que você aceita definem o teto dos seus resultados. Tolerar trabalho malfeito, relacionamentos tóxicos ou hábitos destrutivos não é flexibilidade — é declaração de baixa autoexigência. Responsabilidade pessoal é auditar cada área da vida e eliminar o que está abaixo do padrão que você diz querer. A tolerância ao medíocre é o inimigo do excelente.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Padrões', '#Excelência'],
  },
  {
    headline: 'A conta de todas as suas escolhas chega. Sempre.',
    complementary_text: 'Consequências não têm pressa. Podem levar meses ou anos, mas chegam com precisão matemática. Cada noite mal dormida, cada refeição destruidora, cada hora desperdiçada — tudo soma. Responsabilidade pessoal é viver consciente de que não existe ação sem consequência. O que você planta hoje determina o que colhe amanhã, sem exceção e sem negociação.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Consequência', '#Responsabilidade'],
  },
  {
    headline: 'Delegar culpa é delegar poder. E quem delega poder vive à mercê dos outros.',
    complementary_text: 'Quando você diz que o problema é do governo, do chefe, do parceiro — está dizendo que a solução também está nas mãos deles. E se a solução depende de outro, seu progresso também. Responsabilidade pessoal centraliza o poder de ação em você. Pode ser mais pesado, mas é infinitamente mais eficaz do que esperar que outros consertem sua vida.',
    category: 'Responsabilidade Pessoal',
    hashtags: ['#Poder', '#Autonomia'],
  },

  // ============ CONSTRUÇÃO DE HÁBITOS ============
  {
    headline: 'Você não decide seu futuro. Seus hábitos decidem por você.',
    complementary_text: 'Cada ação repetida diariamente constrói um caminho automático. Depois de semanas, esse caminho se torna trilha. Depois de meses, rodovia. Seus hábitos são a infraestrutura invisível do seu destino. Escolher conscientemente quais comportamentos automatizar é o investimento mais importante que você pode fazer em si mesmo. O futuro é construído no repetitivo.',
    category: 'Construção de Hábitos',
    hashtags: ['#Hábitos', '#Futuro'],
  },
  {
    headline: 'O hábito que você ignora hoje molda a pessoa que você será em cinco anos',
    complementary_text: 'Cinco anos parecem distantes. Mas cada pequena escolha diária — treinar ou pular, ler ou scrollar, criar ou consumir — acumula em trajetórias radicalmente diferentes. A pessoa que você será não depende de uma grande decisão futura. Depende de centenas de micro-decisões que você toma agora, toda vez que escolhe entre o fácil e o necessário.',
    category: 'Construção de Hábitos',
    hashtags: ['#Hábitos', '#MicroDecisões'],
  },
  {
    headline: 'Motivação inicia o hábito. Ambiente e sistema mantêm ele vivo.',
    complementary_text: 'Depender de motivação para manter um hábito é como depender de vento para navegar sem vela. O ambiente precisa facilitar o comportamento desejado e dificultar o indesejado. Colocar o livro na mesa, esconder o celular, preparar a roupa de treino na noite anterior — engenharia de ambiente supera força de vontade em qualquer cenário real.',
    category: 'Construção de Hábitos',
    hashtags: ['#Hábitos', '#Sistema'],
  },
  {
    headline: 'Um hábito de dois minutos feito todo dia supera um de duas horas feito às vezes',
    complementary_text: 'Consistência vence intensidade. A armadilha do perfeccionismo diz que se não puder fazer direito, melhor não fazer. Mentira. Dois minutos de leitura diária criam identidade de leitor. Cinco flexões diárias criam identidade de alguém que treina. O hábito mínimo viável mantém o circuito neural ativo até que a expansão aconteça naturalmente.',
    category: 'Construção de Hábitos',
    hashtags: ['#Consistência', '#HábitoMínimo'],
  },
  {
    headline: 'Todo hábito destrutivo já foi uma solução temporária que você esqueceu de revisar',
    complementary_text: 'O cigarro começou como escape do estresse. O scroll infinito começou como pausa do trabalho. A comida em excesso começou como conforto emocional. Hábitos ruins não surgem do nada — são soluções que funcionaram uma vez e se automatizaram. Construir hábitos melhores exige identificar a necessidade real por trás do comportamento e substituir a resposta, não ignorar o gatilho.',
    category: 'Construção de Hábitos',
    hashtags: ['#Hábitos', '#Autoconhecimento'],
  },
  {
    headline: 'Medir é o que transforma intenção vaga em progresso tangível',
    complementary_text: 'Se você não registra, não sabe se avançou. Achar que está melhorando não é evidência — é viés de confirmação. Hábitos sustentáveis são hábitos mensuráveis: páginas lidas, treinos completados, horas focadas, dinheiro poupado. O que é medido é gerenciado. O que é gerenciado melhora. O que não é medido é apenas esperança sem fundamento.',
    category: 'Construção de Hábitos',
    hashtags: ['#Métricas', '#Progresso'],
  },
  {
    headline: 'Quebrar um dia de sequência não é fracasso. Quebrar dois é escolha.',
    complementary_text: 'A regra dos dois dias é simples: falhar uma vez é humano, falhar duas seguidas é padrão. O primeiro dia perdido é um tropeço. O segundo é uma decisão de voltar ao comportamento antigo. A construção de hábitos exige perdão pelo primeiro e rigidez absoluta contra o segundo. Nunca dois dias seguidos. Essa regra protege meses de progresso acumulado.',
    category: 'Construção de Hábitos',
    hashtags: ['#Hábitos', '#Consistência'],
  },
  {
    headline: 'Identidade precede comportamento. Mude quem você é, não apenas o que faz.',
    complementary_text: 'Fazer dieta é temporário. Ser uma pessoa que se alimenta bem é permanente. Ir à academia é ação. Ser alguém que treina é identidade. Hábitos sustentáveis nascem quando você muda a narrativa interna de eu estou tentando para eu sou. A mudança de identidade não exige permissão — exige repetição até que o cérebro aceite o novo padrão como verdade.',
    category: 'Construção de Hábitos',
    hashtags: ['#Identidade', '#Hábitos'],
  },
  {
    headline: 'O custo de um mau hábito raramente é visível no presente. Mas é inevitável no futuro.',
    complementary_text: 'Pular um treino hoje não dói agora. Comer mal uma vez não aparece no espelho amanhã. Procrastinar uma hora não destrói o projeto hoje. Mas acumule esses micro-abandonos por meses e o resultado é devastador: saúde comprometida, projetos abandonados, potencial desperdiçado. Hábitos ruins cobram em prestações invisíveis com juros compostos impiedosos.',
    category: 'Construção de Hábitos',
    hashtags: ['#Hábitos', '#JurosCompostos'],
  },
  {
    headline: 'Empilhar hábitos em cadeias é engenharia comportamental de alto impacto',
    complementary_text: 'Conectar um novo hábito a um existente reduz a resistência do cérebro à mudança. Após o café, meditar. Após meditar, escrever. Após escrever, treinar. Cada elo da cadeia funciona como gatilho para o próximo. Com o tempo, a sequência inteira se automatiza e o que parecia esforço vira fluxo natural. Projete suas manhãs como linhas de produção pessoal.',
    category: 'Construção de Hábitos',
    hashtags: ['#HabitStacking', '#Rotina'],
  },
  {
    headline: 'O ambiente derrota a vontade. Projete o espaço para o comportamento que deseja.',
    complementary_text: 'Se o celular está na mesa, você vai olhar. Se o chocolate está na geladeira, você vai comer. Se a cama está arrumada para dormir tarde, você vai dormir tarde. Construir hábitos não é sobre mais força de vontade — é sobre menos tentações no ambiente. Remova os gatilhos ruins. Torne os bons inevitáveis. O design do ambiente é o hack definitivo.',
    category: 'Construção de Hábitos',
    hashtags: ['#Ambiente', '#DesignComportamental'],
  },
  {
    headline: 'O hábito mais perigoso é aquele que você nem percebe que tem',
    complementary_text: 'Verificar o celular ao acordar. Reclamar automaticamente do trânsito. Comer sem fome. Procrastinar com falsa produtividade. Hábitos inconscientes dirigem a maior parte do seu dia sem que você perceba. O primeiro passo para construir melhores hábitos é auditar os atuais com honestidade brutal. Só se melhora o que se reconhece como problema real.',
    category: 'Construção de Hábitos',
    hashtags: ['#Consciência', '#Hábitos'],
  },
];

let idCounter = 0;

export const QUOTES_DATABASE: Quote[] = RAW_QUOTES.map((raw) => ({
  id: `quote-${String(++idCounter).padStart(3, '0')}`,
  headline: raw.headline,
  complementary_text: raw.complementary_text,
  category: raw.category,
  hashtags: raw.hashtags,
  is_favorited: false,
  created_at: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
  view_count: 0,
}));
