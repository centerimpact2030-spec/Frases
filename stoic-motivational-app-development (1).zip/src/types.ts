// =============================================
// CONFRONTO DIÁRIO — Type Definitions
// =============================================

export type Category =
  | 'Disciplina Silenciosa'
  | 'Execução Implacável'
  | 'Mentalidade Blindada'
  | 'Resiliência Estoica'
  | 'Antifragilidade'
  | 'Clareza Mental'
  | 'Responsabilidade Pessoal'
  | 'Construção de Hábitos';

export const CATEGORIES: Category[] = [
  'Disciplina Silenciosa',
  'Execução Implacável',
  'Mentalidade Blindada',
  'Resiliência Estoica',
  'Antifragilidade',
  'Clareza Mental',
  'Responsabilidade Pessoal',
  'Construção de Hábitos',
];

export interface Quote {
  id: string;
  headline: string;
  complementary_text: string;
  category: Category;
  hashtags: string[];
  is_favorited: boolean;
  created_at: string;
  view_count: number;
}

export type Screen = 'feed' | 'categories' | 'history' | 'favorites' | 'settings';

export interface AppSettings {
  darkMode: boolean;
  defaultCategory: Category | 'all';
}
