// =============================================
// CONFRONTO DIÁRIO — Favorites Screen
// Collection of saved quotes
// =============================================

import { Heart } from 'lucide-react';
import { Quote } from '../types';
import { QuoteCard } from './QuoteCard';

interface FavoritesProps {
  favoriteQuotes: Quote[];
  onToggleFavorite: (id: string) => void;
  onCopy: (quote: Quote) => Promise<boolean>;
  onShare: (quote: Quote) => Promise<boolean>;
}

export function Favorites({ favoriteQuotes, onToggleFavorite, onCopy, onShare }: FavoritesProps) {
  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-6 pt-12 pb-4">
        <div className="flex items-center gap-2">
          <Heart size={18} className="text-neutral-500" />
          <h2 className="text-[11px] uppercase tracking-[0.25em] text-neutral-500 font-semibold">
            Favoritos
          </h2>
        </div>
        <p className="text-neutral-400 dark:text-neutral-600 text-sm mt-2">
          {favoriteQuotes.length} {favoriteQuotes.length === 1 ? 'frase salva' : 'frases salvas'}
        </p>
      </header>

      {/* Favorites List */}
      {favoriteQuotes.length === 0 ? (
        <div className="flex flex-col items-center justify-center px-6 pt-20">
          <Heart size={40} className="text-neutral-300 dark:text-neutral-700 mb-4" />
          <p className="text-neutral-400 dark:text-neutral-600 text-sm text-center">
            Nenhuma frase favorita ainda.<br />
            Toque no coração para salvar.
          </p>
        </div>
      ) : (
        <div className="px-6 space-y-3">
          {favoriteQuotes.map((quote) => (
            <div
              key={quote.id}
              className="p-5 bg-neutral-50 dark:bg-white/[0.02] rounded-2xl border border-neutral-200/50 dark:border-white/[0.04]"
            >
              <div className="mb-3">
                <span className="text-[10px] uppercase tracking-widest text-neutral-400 dark:text-neutral-600">
                  {quote.category}
                </span>
              </div>
              <QuoteCard
                quote={quote}
                isAnimating={false}
                onToggleFavorite={onToggleFavorite}
                onCopy={onCopy}
                onShare={onShare}
                compact
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
