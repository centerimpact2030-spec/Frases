// =============================================
// CONFRONTO DIÁRIO — Feed Screen (Main)
// Shows one quote at a time with generate action
// =============================================

import { useEffect } from 'react';
import { RefreshCw, Zap } from 'lucide-react';
import { Quote, Category } from '../types';
import { QuoteCard } from './QuoteCard';

interface FeedProps {
  currentQuote: Quote | null;
  isAnimating: boolean;
  activeCategory: Category | 'all';
  onGenerate: (category?: Category | 'all') => void;
  onToggleFavorite: (id: string) => void;
  onCopy: (quote: Quote) => Promise<boolean>;
  onShare: (quote: Quote) => Promise<boolean>;
  onRateQuote: (quoteId: string, category: Category, isPositive: boolean) => void;
}

export function Feed({
  currentQuote,
  isAnimating,
  activeCategory,
  onGenerate,
  onToggleFavorite,
  onCopy,
  onShare,
  onRateQuote,
}: FeedProps) {
  // Auto-generate first quote on mount
  useEffect(() => {
    if (!currentQuote) {
      onGenerate(activeCategory);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="px-6 pt-12 pb-4">
        <div className="flex items-center gap-2">
          <Zap size={18} className="text-neutral-500 dark:text-neutral-500" />
          <h2 className="text-[11px] uppercase tracking-[0.25em] text-neutral-500 dark:text-neutral-500 font-semibold">
            Confronto Diário
          </h2>
        </div>
      </header>

      {/* Quote Content */}
      <main className="flex-1 flex flex-col justify-center px-6 pb-8">
        {currentQuote ? (
          <QuoteCard
            quote={currentQuote}
            isAnimating={isAnimating}
            onToggleFavorite={onToggleFavorite}
            onCopy={onCopy}
            onShare={onShare}
            onRateQuote={onRateQuote}
          />
        ) : (
          <div className="text-center text-neutral-500">
            <p className="text-sm">Carregando seu confronto...</p>
          </div>
        )}
      </main>

      {/* Generate Button */}
      <div className="px-6 pb-24">
        <button
          onClick={() => onGenerate(activeCategory)}
          disabled={isAnimating}
          className="w-full py-4 rounded-2xl bg-neutral-900 dark:bg-white/[0.08] hover:bg-neutral-800 dark:hover:bg-white/[0.12] text-white dark:text-neutral-200 font-semibold text-sm tracking-wide transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50 active:scale-[0.98]"
        >
          <RefreshCw size={16} className={isAnimating ? 'animate-spin' : ''} />
          NOVO CONFRONTO
        </button>
      </div>
    </div>
  );
}
