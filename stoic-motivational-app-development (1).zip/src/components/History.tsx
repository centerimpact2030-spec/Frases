// =============================================
// CONFRONTO DIÁRIO — History Screen
// Chronological list of viewed quotes
// =============================================

import { Clock, Trash2 } from 'lucide-react';
import { Quote } from '../types';
import { QuoteCard } from './QuoteCard';

interface HistoryProps {
  historyQuotes: (Quote & { viewedAt: string })[];
  onToggleFavorite: (id: string) => void;
  onCopy: (quote: Quote) => Promise<boolean>;
  onShare: (quote: Quote) => Promise<boolean>;
  onClearHistory: () => void;
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Agora';
  if (diffMins < 60) return `${diffMins}min atrás`;
  if (diffHours < 24) return `${diffHours}h atrás`;
  if (diffDays < 7) return `${diffDays}d atrás`;
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

export function History({ historyQuotes, onToggleFavorite, onCopy, onShare, onClearHistory }: HistoryProps) {
  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-6 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock size={18} className="text-neutral-500" />
            <h2 className="text-[11px] uppercase tracking-[0.25em] text-neutral-500 font-semibold">
              Histórico
            </h2>
          </div>
          {historyQuotes.length > 0 && (
            <button
              onClick={onClearHistory}
              className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-red-500 transition-colors px-3 py-1.5 rounded-lg hover:bg-red-500/10"
            >
              <Trash2 size={13} />
              Limpar
            </button>
          )}
        </div>
        <p className="text-neutral-400 dark:text-neutral-600 text-sm mt-2">
          {historyQuotes.length} {historyQuotes.length === 1 ? 'frase visualizada' : 'frases visualizadas'}
        </p>
      </header>

      {/* Quote List */}
      {historyQuotes.length === 0 ? (
        <div className="flex flex-col items-center justify-center px-6 pt-20">
          <Clock size={40} className="text-neutral-300 dark:text-neutral-700 mb-4" />
          <p className="text-neutral-400 dark:text-neutral-600 text-sm text-center">
            Nenhuma frase no histórico ainda.<br />
            Gere seu primeiro confronto.
          </p>
        </div>
      ) : (
        <div className="px-6 space-y-3">
          {historyQuotes.map((quote, index) => (
            <div
              key={`${quote.id}-${index}`}
              className="p-5 bg-neutral-50 dark:bg-white/[0.02] rounded-2xl border border-neutral-200/50 dark:border-white/[0.04]"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] uppercase tracking-widest text-neutral-400 dark:text-neutral-600">
                  {quote.category}
                </span>
                <span className="text-[10px] text-neutral-400 dark:text-neutral-600">
                  {formatDate(quote.viewedAt)}
                </span>
              </div>
              <QuoteCard
                quote={quote}
                isAnimating={false}
                onToggleFavorite={onToggleFavorite}
                onCopy={onCopy}
                onShare={onShare}
                compact
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
