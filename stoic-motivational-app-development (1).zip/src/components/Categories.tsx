// =============================================
// CONFRONTO DIÁRIO — Categories Screen
// Filter and browse quotes by category
// =============================================

import { Quote, Category, CATEGORIES } from '../types';
import { QuoteCard } from './QuoteCard';
import { useState } from 'react';
import { ChevronRight, Grid3X3 } from 'lucide-react';

interface CategoriesProps {
  activeCategory: Category | 'all';
  onSetCategory: (cat: Category | 'all') => void;
  getQuotesByCategory: (cat: Category) => Quote[];
  onGenerate: (cat?: Category | 'all') => void;
  onToggleFavorite: (id: string) => void;
  onCopy: (quote: Quote) => Promise<boolean>;
  onShare: (quote: Quote) => Promise<boolean>;
  favorites: string[];
}

const CATEGORY_ICONS: Record<Category, string> = {
  'Disciplina Silenciosa': '🔇',
  'Execução Implacável': '⚡',
  'Mentalidade Blindada': '🛡️',
  'Resiliência Estoica': '🏛️',
  'Antifragilidade': '💎',
  'Clareza Mental': '🎯',
  'Responsabilidade Pessoal': '⚖️',
  'Construção de Hábitos': '🔄',
};

export function Categories({
  activeCategory,
  onSetCategory,
  getQuotesByCategory,
  onGenerate,
  onToggleFavorite,
  onCopy,
  onShare,
  favorites,
}: CategoriesProps) {
  const [expandedCategory, setExpandedCategory] = useState<Category | null>(null);

  const handleCategoryClick = (cat: Category) => {
    if (expandedCategory === cat) {
      setExpandedCategory(null);
    } else {
      setExpandedCategory(cat);
    }
  };

  const handleSelectCategory = (cat: Category) => {
    onSetCategory(cat);
    onGenerate(cat);
  };

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-2 mb-1">
          <Grid3X3 size={18} className="text-neutral-500" />
          <h2 className="text-[11px] uppercase tracking-[0.25em] text-neutral-500 font-semibold">
            Categorias
          </h2>
        </div>
        <p className="text-neutral-400 dark:text-neutral-600 text-sm mt-2">
          Escolha uma categoria para direcionar seu confronto
        </p>
      </header>

      {/* Active Category Badge */}
      {activeCategory !== 'all' && (
        <div className="px-6 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-500">Filtro ativo:</span>
            <span className="text-xs bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 px-3 py-1 rounded-full font-medium">
              {activeCategory}
            </span>
            <button
              onClick={() => onSetCategory('all')}
              className="text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 underline"
            >
              Limpar
            </button>
          </div>
        </div>
      )}

      {/* Category List */}
      <div className="px-6 space-y-2">
        {CATEGORIES.map((cat) => {
          const quotes = getQuotesByCategory(cat);
          const favCount = quotes.filter(q => favorites.includes(q.id)).length;
          const isExpanded = expandedCategory === cat;
          const isActive = activeCategory === cat;

          return (
            <div key={cat} className="overflow-hidden">
              {/* Category Header */}
              <button
                onClick={() => handleCategoryClick(cat)}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-200 ${
                  isActive
                    ? 'bg-neutral-200/80 dark:bg-white/[0.08]'
                    : 'bg-neutral-100 dark:bg-white/[0.03] hover:bg-neutral-200/50 dark:hover:bg-white/[0.06]'
                }`}
              >
                <span className="text-xl">{CATEGORY_ICONS[cat]}</span>
                <div className="flex-1 text-left">
                  <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
                    {cat}
                  </h3>
                  <p className="text-xs text-neutral-500 mt-0.5">
                    {quotes.length} frases{favCount > 0 ? ` · ${favCount} favoritas` : ''}
                  </p>
                </div>
                <ChevronRight
                  size={16}
                  className={`text-neutral-400 transition-transform duration-200 ${
                    isExpanded ? 'rotate-90' : ''
                  }`}
                />
              </button>

              {/* Expanded Content */}
              {isExpanded && (
                <div className="mt-2 space-y-3 pl-2">
                  {/* Use this category button */}
                  <button
                    onClick={() => handleSelectCategory(cat)}
                    className="w-full py-3 text-sm font-medium text-neutral-600 dark:text-neutral-400 bg-neutral-100 dark:bg-white/[0.04] rounded-xl hover:bg-neutral-200 dark:hover:bg-white/[0.08] transition-colors"
                  >
                    Gerar frase de "{cat}"
                  </button>

                  {/* Preview first 2 quotes */}
                  {quotes.slice(0, 2).map((quote) => (
                    <div key={quote.id} className="p-4 bg-neutral-50 dark:bg-white/[0.02] rounded-xl border border-neutral-200/50 dark:border-white/[0.04]">
                      <QuoteCard
                        quote={{ ...quote, is_favorited: favorites.includes(quote.id) }}
                        isAnimating={false}
                        onToggleFavorite={onToggleFavorite}
                        onCopy={onCopy}
                        onShare={onShare}
                        compact
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
