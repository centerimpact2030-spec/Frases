// =============================================
// CONFRONTO DIÁRIO — Settings Screen
// Theme toggle, default category, clear data
// =============================================

import { Settings as SettingsIcon, Moon, Sun, Tag, Trash2, Database, Shield } from 'lucide-react';
import { Category, CATEGORIES } from '../types';

import { Brain } from 'lucide-react';

interface SettingsProps {
  darkMode: boolean;
  onToggleTheme: () => void;
  defaultCategory: Category | 'all';
  onSetDefaultCategory: (cat: Category | 'all') => void;
  onClearHistory: () => void;
  historyCount: number;
  favoritesCount: number;
  totalQuotes: number;
  evolutionProfile?: {
    categoryWeights: Record<string, number>;
    tonePreferences: Record<string, number>;
    totalEvaluations: number;
  };
}

export function Settings({
  darkMode,
  onToggleTheme,
  defaultCategory,
  onSetDefaultCategory,
  onClearHistory,
  historyCount,
  favoritesCount,
  totalQuotes,
  evolutionProfile,
}: SettingsProps) {
  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-2">
          <SettingsIcon size={18} className="text-neutral-500" />
          <h2 className="text-[11px] uppercase tracking-[0.25em] text-neutral-500 font-semibold">
            Configurações
          </h2>
        </div>
      </header>

      <div className="px-6 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-neutral-100 dark:bg-white/[0.03] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-neutral-800 dark:text-neutral-200">{totalQuotes}</p>
            <p className="text-[10px] uppercase tracking-wider text-neutral-400 dark:text-neutral-600 mt-1">Frases</p>
          </div>
          <div className="bg-neutral-100 dark:bg-white/[0.03] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-neutral-800 dark:text-neutral-200">{historyCount}</p>
            <p className="text-[10px] uppercase tracking-wider text-neutral-400 dark:text-neutral-600 mt-1">Vistas</p>
          </div>
          <div className="bg-neutral-100 dark:bg-white/[0.03] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-neutral-800 dark:text-neutral-200">{favoritesCount}</p>
            <p className="text-[10px] uppercase tracking-wider text-neutral-400 dark:text-neutral-600 mt-1">Salvas</p>
          </div>
        </div>

        {/* Evolution AI Dashboard */}
        {evolutionProfile && (
          <div>
            <h3 className="text-[10px] uppercase tracking-[0.2em] text-neutral-400 dark:text-neutral-600 font-semibold mb-3 px-1 flex items-center gap-2">
              🧠 Motor de Evolução & Aprendizado
            </h3>
            <div className="bg-neutral-100 dark:bg-white/[0.03] rounded-2xl p-5 space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-neutral-200/50 dark:border-white/[0.04]">
                <p className="text-xs font-medium text-neutral-600 dark:text-neutral-400">Avaliações feitas:</p>
                <span className="text-sm font-bold text-neutral-800 dark:text-neutral-200">{evolutionProfile.totalEvaluations}</span>
              </div>
              
              <div>
                <p className="text-[10px] uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-2 font-semibold">Tons preferidos do usuário:</p>
                <div className="space-y-2">
                  {Object.entries(evolutionProfile.tonePreferences).map(([tone, weight]) => (
                    <div key={tone} className="flex items-center gap-2">
                      <span className="text-xs capitalize text-neutral-600 dark:text-neutral-400 w-24 truncate">{tone}:</span>
                      <div className="flex-1 h-1.5 bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-neutral-500 dark:bg-neutral-400 transition-all duration-300"
                          style={{ width: `${Math.min(100, (weight / 15) * 100)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <p className="text-[10px] text-neutral-400 dark:text-neutral-500 leading-relaxed italic border-t border-neutral-200/50 dark:border-white/[0.04] pt-2">
                *O motor sintetiza novos confrontos focados em profundidade, evitando superficialidades de acordo com suas avaliações.
              </p>
            </div>
          </div>
        )}

        {/* Appearance */}
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-neutral-400 dark:text-neutral-600 font-semibold mb-3 px-1">
            Aparência
          </h3>
          <button
            onClick={onToggleTheme}
            className="w-full flex items-center justify-between p-4 bg-neutral-100 dark:bg-white/[0.03] rounded-2xl hover:bg-neutral-200/80 dark:hover:bg-white/[0.06] transition-colors"
          >
            <div className="flex items-center gap-3">
              {darkMode ? <Moon size={18} className="text-neutral-400" /> : <Sun size={18} className="text-amber-500" />}
              <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">
                {darkMode ? 'Modo Escuro' : 'Modo Claro'}
              </span>
            </div>
            <div className={`w-11 h-6 rounded-full relative transition-colors duration-200 ${
              darkMode ? 'bg-neutral-600' : 'bg-neutral-300'
            }`}>
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-200 ${
                darkMode ? 'translate-x-5' : 'translate-x-0.5'
              }`} />
            </div>
          </button>
        </div>

        {/* Default Category */}
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-neutral-400 dark:text-neutral-600 font-semibold mb-3 px-1 flex items-center gap-2">
            <Tag size={12} />
            Categoria Padrão
          </h3>
          <div className="space-y-1">
            <button
              onClick={() => onSetDefaultCategory('all')}
              className={`w-full flex items-center gap-3 p-3 rounded-xl text-sm transition-colors ${
                defaultCategory === 'all'
                  ? 'bg-neutral-200 dark:bg-white/[0.08] text-neutral-800 dark:text-neutral-200 font-medium'
                  : 'text-neutral-500 hover:bg-neutral-100 dark:hover:bg-white/[0.03]'
              }`}
            >
              <span className="text-base">🔀</span>
              Todas (Aleatório)
            </button>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => onSetDefaultCategory(cat)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl text-sm transition-colors ${
                  defaultCategory === cat
                    ? 'bg-neutral-200 dark:bg-white/[0.08] text-neutral-800 dark:text-neutral-200 font-medium'
                    : 'text-neutral-500 hover:bg-neutral-100 dark:hover:bg-white/[0.03]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Data Management */}
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-neutral-400 dark:text-neutral-600 font-semibold mb-3 px-1 flex items-center gap-2">
            <Database size={12} />
            Dados
          </h3>
          <button
            onClick={onClearHistory}
            className="w-full flex items-center justify-between p-4 bg-neutral-100 dark:bg-white/[0.03] rounded-2xl hover:bg-red-50 dark:hover:bg-red-500/5 transition-colors group"
          >
            <div className="flex items-center gap-3">
              <Trash2 size={18} className="text-neutral-400 group-hover:text-red-500 transition-colors" />
              <div className="text-left">
                <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">
                  Limpar Histórico
                </span>
                <p className="text-xs text-neutral-400 dark:text-neutral-600 mt-0.5">
                  Remove todas as frases vistas
                </p>
              </div>
            </div>
          </button>
        </div>

        {/* About */}
        <div className="pt-4 pb-8">
          <div className="flex items-center gap-2 mb-3">
            <Shield size={12} className="text-neutral-400 dark:text-neutral-600" />
            <h3 className="text-[10px] uppercase tracking-[0.2em] text-neutral-400 dark:text-neutral-600 font-semibold">
              Sobre
            </h3>
          </div>
          <div className="bg-neutral-100 dark:bg-white/[0.03] rounded-2xl p-5">
            <p className="text-sm font-bold text-neutral-700 dark:text-neutral-300 mb-2">
              Confronto Diário
            </p>
            <p className="text-xs text-neutral-400 dark:text-neutral-600 leading-relaxed">
              Treino mental diário baseado em estoicismo moderno, disciplina e alta performance. 
              Sem clichês. Sem romantização. Apenas verdades que confrontam e constroem.
            </p>
            <div className="mt-3 pt-3 border-t border-neutral-200/50 dark:border-white/[0.04]">
              <p className="text-[10px] text-neutral-400 dark:text-neutral-600">
                v1.0.0 · Offline-first · {totalQuotes} frases no banco
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
