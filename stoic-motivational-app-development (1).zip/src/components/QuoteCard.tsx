// =============================================
// CONFRONTO DIÁRIO — Quote Card Component
// Displays a single quote with actions
// =============================================

import { useState } from 'react';
import { Heart, Copy, Share2, Check } from 'lucide-react';
import { Quote } from '../types';

import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { Category } from '../types';

interface QuoteCardProps {
  quote: Quote;
  isAnimating: boolean;
  onToggleFavorite: (id: string) => void;
  onCopy: (quote: Quote) => Promise<boolean>;
  onShare: (quote: Quote) => Promise<boolean>;
  onRateQuote?: (quoteId: string, category: Category, isPositive: boolean) => void;
  compact?: boolean;
}

export function QuoteCard({ quote, isAnimating, onToggleFavorite, onCopy, onShare, onRateQuote, compact = false }: QuoteCardProps) {
  const [copied, setCopied] = useState(false);
  const [rated, setRated] = useState<'positive' | 'negative' | null>(null);

  const handleRate = (isPositive: boolean) => {
    if (!onRateQuote) return;
    onRateQuote(quote.id, quote.category, isPositive);
    setRated(isPositive ? 'positive' : 'negative');
  };

  const handleCopy = async () => {
    const success = await onCopy(quote);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className={`transition-all duration-300 ease-out ${
        isAnimating ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
      }`}
    >
      {/* Category Badge */}
      <div className="mb-6">
        <span className="text-[11px] uppercase tracking-[0.2em] text-neutral-500 dark:text-neutral-500 font-medium">
          {quote.category}
        </span>
      </div>

      {/* Headline */}
      <h1 className={`font-bold leading-tight text-neutral-900 dark:text-[#EAEAEA] mb-6 ${
        compact ? 'text-lg' : 'text-[22px] sm:text-[26px]'
      }`}>
        {quote.headline}
      </h1>

      {/* Complementary Text */}
      <p className={`text-neutral-600 dark:text-neutral-400 leading-relaxed mb-6 ${
        compact ? 'text-sm' : 'text-[15px] sm:text-base'
      }`}>
        {quote.complementary_text}
      </p>

      {/* Hashtags */}
      <div className="flex flex-wrap gap-2 mb-8">
        {quote.hashtags.map((tag, i) => (
          <span
            key={i}
            className="text-xs text-neutral-500 dark:text-neutral-500 font-medium"
          >
            {tag}
          </span>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-1">
        <button
          onClick={() => onToggleFavorite(quote.id)}
          className={`p-3 rounded-xl transition-all duration-200 ${
            quote.is_favorited
              ? 'text-red-500 bg-red-500/10'
              : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800/50'
          }`}
          aria-label={quote.is_favorited ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
        >
          <Heart size={20} fill={quote.is_favorited ? 'currentColor' : 'none'} />
        </button>

        {onRateQuote && (
          <>
            <button
              onClick={() => handleRate(true)}
              className={`p-3 rounded-xl transition-all duration-200 ${
                rated === 'positive'
                  ? 'text-green-500 bg-green-500/10'
                  : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800/50'
              }`}
              aria-label="Curtir este estilo"
            >
              <ThumbsUp size={18} fill={rated === 'positive' ? 'currentColor' : 'none'} />
            </button>

            <button
              onClick={() => handleRate(false)}
              className={`p-3 rounded-xl transition-all duration-200 ${
                rated === 'negative'
                  ? 'text-orange-500 bg-orange-500/10'
                  : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800/50'
              }`}
              aria-label="Evitar este estilo"
            >
              <ThumbsDown size={18} fill={rated === 'negative' ? 'currentColor' : 'none'} />
            </button>
          </>
        )}

        <button
          onClick={handleCopy}
          className="p-3 rounded-xl text-neutral-400 dark:text-neutral-500 hover:text-neutral-600 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800/50 transition-all duration-200"
          aria-label="Copiar frase"
        >
          {copied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
        </button>

        <button
          onClick={() => onShare(quote)}
          className="p-3 rounded-xl text-neutral-400 dark:text-neutral-500 hover:text-neutral-600 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800/50 transition-all duration-200"
          aria-label="Compartilhar frase"
        >
          <Share2 size={20} />
        </button>
      </div>
    </div>
  );
}
