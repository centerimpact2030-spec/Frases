// =============================================
// CONFRONTO DIÁRIO — Bottom Navigation
// Mobile-first tab navigation
// =============================================

import { Zap, Grid3X3, Clock, Heart, Settings } from 'lucide-react';
import { Screen } from '../types';

interface NavigationProps {
  activeScreen: Screen;
  onNavigate: (screen: Screen) => void;
  favoritesCount: number;
}

const NAV_ITEMS: { screen: Screen; icon: typeof Zap; label: string }[] = [
  { screen: 'feed', icon: Zap, label: 'Feed' },
  { screen: 'categories', icon: Grid3X3, label: 'Categorias' },
  { screen: 'history', icon: Clock, label: 'Histórico' },
  { screen: 'favorites', icon: Heart, label: 'Favoritos' },
  { screen: 'settings', icon: Settings, label: 'Config' },
];

export function Navigation({ activeScreen, onNavigate, favoritesCount }: NavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      {/* Gradient fade */}
      <div className="absolute inset-x-0 -top-6 h-6 bg-gradient-to-t from-white dark:from-[#0A0A0A] to-transparent pointer-events-none" />
      
      {/* Nav bar */}
      <div className="bg-white/90 dark:bg-[#0A0A0A]/90 backdrop-blur-xl border-t border-neutral-200/30 dark:border-white/[0.04]">
        <div className="max-w-lg mx-auto flex items-center justify-around px-2 pb-[env(safe-area-inset-bottom,8px)]">
          {NAV_ITEMS.map(({ screen, icon: Icon, label }) => {
            const isActive = activeScreen === screen;
            return (
              <button
                key={screen}
                onClick={() => onNavigate(screen)}
                className={`relative flex flex-col items-center gap-1 py-3 px-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'text-neutral-900 dark:text-white'
                    : 'text-neutral-400 dark:text-neutral-600 hover:text-neutral-600 dark:hover:text-neutral-400'
                }`}
              >
                <div className="relative">
                  <Icon size={20} strokeWidth={isActive ? 2.2 : 1.5} />
                  {screen === 'favorites' && favoritesCount > 0 && (
                    <span className="absolute -top-1.5 -right-2 w-4 h-4 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center font-bold">
                      {favoritesCount > 9 ? '9+' : favoritesCount}
                    </span>
                  )}
                </div>
                <span className={`text-[9px] tracking-wider uppercase ${isActive ? 'font-bold' : 'font-medium'}`}>
                  {label}
                </span>
                {isActive && (
                  <div className="absolute -top-px left-1/2 -translate-x-1/2 w-6 h-0.5 bg-neutral-900 dark:bg-white rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
