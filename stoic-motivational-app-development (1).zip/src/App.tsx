// =============================================
// CONFRONTO DIÁRIO — Main App Component
// Entry point with navigation and state management
// =============================================
// 
// INTEGRATION NOTES:
// ------------------
// 1. QUOTE ENGINE: Currently uses a pre-loaded database of 96 quotes.
//    To integrate an LLM API (e.g., OpenAI), modify the `generateQuote` 
//    function in `src/hooks/useQuotes.ts` to call your API endpoint 
//    with the system prompt defined in the spec.
//
// 2. PERSISTENCE: Uses localStorage for offline-first experience.
//    To add cloud sync, wrap the `useLocalStorage` hook with your
//    preferred backend (Firebase, Supabase, etc.).
//
// 3. VALIDATION: Content validation rules are in `src/utils/validation.ts`.
//    All quotes pass through cliché detection and word/char counting.
//
// 4. OFFLINE CACHE: Last 50 quotes are cached automatically.
//    The app works fully offline after first load.
// =============================================

import { useState } from 'react';
import { Screen } from './types';
import { useTheme } from './hooks/useTheme';
import { useQuotes } from './hooks/useQuotes';

import { Feed } from './components/Feed';
import { Categories } from './components/Categories';
import { History } from './components/History';
import { Favorites } from './components/Favorites';
import { Settings } from './components/Settings';
import { Navigation } from './components/Navigation';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('feed');
  const { darkMode, toggleTheme } = useTheme();
  
  const {
    currentQuote,
    isAnimating,
    activeCategory,
    setActiveCategory,
    generateQuote,
    toggleFavorite,
    favoriteQuotes,
    historyQuotes,
    clearHistory,
    copyQuote,
    shareQuote,
    getQuotesByCategory,
    allQuotes,
    favorites,
    rateQuote,
  } = useQuotes();

  const handleNavigate = (screen: Screen) => {
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#0A0A0A] text-neutral-900 dark:text-[#EAEAEA] font-['Inter',sans-serif] antialiased">
      <div className="max-w-lg mx-auto relative">
        {/* Screen Content */}
        <div className="min-h-screen">
          {activeScreen === 'feed' && (
            <Feed
              currentQuote={currentQuote}
              isAnimating={isAnimating}
              activeCategory={activeCategory}
              onGenerate={generateQuote}
              onToggleFavorite={toggleFavorite}
              onCopy={copyQuote}
              onShare={shareQuote}
              onRateQuote={rateQuote}
            />
          )}

          {activeScreen === 'categories' && (
            <Categories
              activeCategory={activeCategory}
              onSetCategory={(cat) => {
                setActiveCategory(cat);
              }}
              getQuotesByCategory={getQuotesByCategory}
              onGenerate={(cat) => {
                generateQuote(cat);
                setActiveScreen('feed');
              }}
              onToggleFavorite={toggleFavorite}
              onCopy={copyQuote}
              onShare={shareQuote}
              favorites={favorites}
            />
          )}

          {activeScreen === 'history' && (
            <History
              historyQuotes={historyQuotes}
              onToggleFavorite={toggleFavorite}
              onCopy={copyQuote}
              onShare={shareQuote}
              onClearHistory={clearHistory}
            />
          )}

          {activeScreen === 'favorites' && (
            <Favorites
              favoriteQuotes={favoriteQuotes}
              onToggleFavorite={toggleFavorite}
              onCopy={copyQuote}
              onShare={shareQuote}
            />
          )}

          {activeScreen === 'settings' && (
            <Settings
              darkMode={darkMode}
              onToggleTheme={toggleTheme}
              defaultCategory={activeCategory}
              onSetDefaultCategory={setActiveCategory}
              onClearHistory={clearHistory}
              historyCount={historyQuotes.length}
              favoritesCount={favoriteQuotes.length}
              totalQuotes={allQuotes.length}
            />
          )}
        </div>

        {/* Bottom Navigation */}
        <Navigation
          activeScreen={activeScreen}
          onNavigate={handleNavigate}
          favoritesCount={favoriteQuotes.length}
        />
      </div>
    </div>
  );
}
