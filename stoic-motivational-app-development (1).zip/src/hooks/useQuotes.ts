// =============================================
// CONFRONTO DIÁRIO — Quote Management Hook
// Handles quote selection, history, favorites,
// and ensures no repetition
// =============================================

import { useState, useCallback, useMemo } from 'react';
import { Quote, Category } from '../types';
import { QUOTES_DATABASE } from '../data/quotes';
import { useLocalStorage } from './useLocalStorage';
import { EvolutionProfile, INITIAL_PROFILE, synthesizeQuote, evolveProfile } from '../utils/synthesizer';

const HISTORY_LIMIT = 500;

export function useQuotes() {
  // Persist favorites, history, and seen quotes
  const [favorites, setFavorites] = useLocalStorage<string[]>('cd_favorites', []);
  const [history, setHistory] = useLocalStorage<{ id: string; viewedAt: string }[]>('cd_history', []);
  const [seenIds, setSeenIds] = useLocalStorage<string[]>('cd_seen_ids', []);

  // Evolution profile state
  const [evolutionProfile, setEvolutionProfile] = useLocalStorage<EvolutionProfile>('cd_evolution_profile', INITIAL_PROFILE);

  // Current quote state
  const [currentQuote, setCurrentQuote] = useState<Quote | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [activeCategory, setActiveCategory] = useState<Category | 'all'>('all');

  // Build the full quotes list with favorite status
  const allQuotes = useMemo(() => {
    return QUOTES_DATABASE.map(q => ({
      ...q,
      is_favorited: favorites.includes(q.id),
    }));
  }, [favorites]);

  // Get available quotes (not yet seen in current cycle)
  const getAvailableQuotes = useCallback((category: Category | 'all') => {
    let pool = allQuotes;
    if (category !== 'all') {
      pool = pool.filter(q => q.category === category);
    }

    // Filter out seen quotes
    const unseen = pool.filter(q => !seenIds.includes(q.id));

    // If all have been seen, reset the cycle
    if (unseen.length === 0) {
      setSeenIds([]);
      return pool;
    }

    return unseen;
  }, [allQuotes, seenIds, setSeenIds]);

  // Generate a new random quote
  const generateQuote = useCallback((category?: Category | 'all') => {
    const cat = category ?? activeCategory;
    
    // 50% chance to generate a synthesized quote or if pre-loaded run out
    const generateSynthesized = Math.random() > 0.4;
    
    setIsAnimating(true);

    setTimeout(() => {
      let quote: Quote;

      if (generateSynthesized) {
        quote = synthesizeQuote(evolutionProfile, cat);
      } else {
        const available = getAvailableQuotes(cat);
        if (available.length > 0) {
          const randomIndex = Math.floor(Math.random() * available.length);
          quote = available[randomIndex];
        } else {
          // Fallback to synthesis if all seen
          quote = synthesizeQuote(evolutionProfile, cat);
        }
      }

      setCurrentQuote(quote);
      setIsAnimating(false);

      // Track in seen
      setSeenIds(prev => [...prev, quote.id]);

      // Add to history
      setHistory(prev => {
        const newEntry = { id: quote.id, viewedAt: new Date().toISOString() };
        const updated = [newEntry, ...prev].slice(0, HISTORY_LIMIT);
        return updated;
      });
    }, 150);
  }, [activeCategory, getAvailableQuotes, setSeenIds, setHistory, evolutionProfile]);

  // Rate quote (Like / Dislike) to evolve the profile
  const rateQuote = useCallback((quoteId: string, category: Category, isPositive: boolean) => {
    setEvolutionProfile(prev => evolveProfile(prev, category, isPositive));
    
    // Also toggle favorite if positive and not favorited yet
    if (isPositive && !favorites.includes(quoteId)) {
      setFavorites(prev => [...prev, quoteId]);
      if (currentQuote && currentQuote.id === quoteId) {
        setCurrentQuote(prev => prev ? { ...prev, is_favorited: true } : null);
      }
    }
  }, [setEvolutionProfile, favorites, currentQuote]);

  // Toggle favorite
  const toggleFavorite = useCallback((quoteId: string) => {
    setFavorites(prev => {
      if (prev.includes(quoteId)) {
        return prev.filter(id => id !== quoteId);
      }
      return [...prev, quoteId];
    });

    // Update current quote if it's the one being toggled
    if (currentQuote && currentQuote.id === quoteId) {
      setCurrentQuote(prev => prev ? { ...prev, is_favorited: !prev.is_favorited } : null);
    }
  }, [setFavorites, currentQuote]);

  // Get favorite quotes
  const favoriteQuotes = useMemo(() => {
    return allQuotes.filter(q => favorites.includes(q.id));
  }, [allQuotes, favorites]);

  // Get history quotes with timestamps
  const historyQuotes = useMemo(() => {
    return history.map(h => {
      const quote = allQuotes.find(q => q.id === h.id);
      return quote ? { ...quote, viewedAt: h.viewedAt } : null;
    }).filter(Boolean) as (Quote & { viewedAt: string })[];
  }, [history, allQuotes]);

  // Clear history
  const clearHistory = useCallback(() => {
    setHistory([]);
    setSeenIds([]);
  }, [setHistory, setSeenIds]);

  // Copy quote to clipboard
  const copyQuote = useCallback(async (quote: Quote) => {
    const text = `${quote.headline}\n\n${quote.complementary_text}\n\n${quote.hashtags.join(' ')}`;
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      return true;
    }
  }, []);

  // Share quote
  const shareQuote = useCallback(async (quote: Quote) => {
    const text = `${quote.headline}\n\n${quote.complementary_text}\n\n${quote.hashtags.join(' ')}\n\n— Confronto Diário`;
    if (navigator.share) {
      try {
        await navigator.share({ text });
        return true;
      } catch {
        return false;
      }
    } else {
      return copyQuote(quote);
    }
  }, [copyQuote]);

  // Get quotes by category
  const getQuotesByCategory = useCallback((category: Category) => {
    return allQuotes.filter(q => q.category === category);
  }, [allQuotes]);

  return {
    currentQuote,
    isAnimating,
    activeCategory,
    setActiveCategory,
    generateQuote,
    toggleFavorite,
    favoriteQuotes,
    historyQuotes,
    clearHistory,
    copyQuote,
    shareQuote,
    getQuotesByCategory,
    allQuotes,
    favorites,
    rateQuote,
    evolutionProfile,
  };
}
