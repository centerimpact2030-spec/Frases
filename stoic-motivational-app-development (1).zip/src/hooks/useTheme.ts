// =============================================
// CONFRONTO DIÁRIO — Theme Hook
// Dark mode enabled by default
// =============================================

import { useEffect } from 'react';
import { useLocalStorage } from './useLocalStorage';

export function useTheme() {
  const [darkMode, setDarkMode] = useLocalStorage<boolean>('cd_dark_mode', true);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleTheme = () => setDarkMode(prev => !prev);

  return { darkMode, toggleTheme, setDarkMode };
}
