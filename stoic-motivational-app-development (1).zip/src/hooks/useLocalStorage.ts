// =============================================
// CONFRONTO DIÁRIO — Local Storage Hook
// Persistence layer for offline-first experience
// =============================================

import { useState, useCallback } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((prev: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback((value: T | ((prev: T) => T)) => {
    setStoredValue(prev => {
      const valueToStore = value instanceof Function ? value(prev) : value;
      try {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (e) {
        console.warn(`Failed to save to localStorage key "${key}":`, e);
      }
      return valueToStore;
    });
  }, [key]);

  return [storedValue, setValue];
}

// Cache management for offline-first
export function getCachedQuotes(): string[] {
  try {
    const cached = localStorage.getItem('cd_cached_quotes');
    return cached ? JSON.parse(cached) : [];
  } catch {
    return [];
  }
}

export function setCachedQuotes(ids: string[]): void {
  try {
    // Keep only last 50 for offline cache
    const limited = ids.slice(-50);
    localStorage.setItem('cd_cached_quotes', JSON.stringify(limited));
  } catch (e) {
    console.warn('Failed to cache quotes:', e);
  }
}
